from __future__ import annotations

import json
import sys
from pathlib import Path

# Ensure repo root is importable even when running this script directly.
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from clearsignal_core.ingest import read_csv_signal, read_csv_system
from clearsignal_core.report import analyze_signal, analyze_system

OUT = ROOT / "demos" / "output"
OUT.mkdir(parents=True, exist_ok=True)

def main() -> None:
    sleep = read_csv_signal(str(ROOT / "sample_data" / "sleep_example.csv"), "date", "sleep_hours")
    r1 = analyze_signal(sleep, signal_name="sleep_hours", template="recovery")
    (OUT / "sleep_report.json").write_text(json.dumps(r1.to_dict(), indent=2), encoding="utf-8")

    system = read_csv_system(str(ROOT / "sample_data" / "system_example.csv"), "date", ["sleep_hours", "resting_hr", "hrv"])
    r2 = analyze_system(system, system_name="Recovery", template="recovery")
    (OUT / "system_report.json").write_text(json.dumps(r2.to_dict(), indent=2), encoding="utf-8")

    cash = read_csv_system(str(ROOT / "sample_data" / "cashflow_example.csv"), "date", ["revenue", "expenses"])
    r3 = analyze_system(cash, system_name="Cashflow", template="cashflow")
    (OUT / "cashflow_system_report.json").write_text(json.dumps(r3.to_dict(), indent=2), encoding="utf-8")

    print("Wrote:")
    for p in sorted(OUT.glob("*.json")):
        print(" -", p.relative_to(ROOT))

if __name__ == "__main__":
    main()
