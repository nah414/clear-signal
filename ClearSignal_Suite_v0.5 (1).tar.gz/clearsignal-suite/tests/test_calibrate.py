import numpy as np
import pandas as pd
from clearsignal_core.calibrate import calibrate_signal

def test_calibrate_recommends_overrides():
    rng = np.random.default_rng(1)
    dates = pd.date_range("2025-01-01", periods=220, freq="D")
    # Stable series with mild weekly seasonality
    y = 10 + (dates.weekday >= 5) * 1.0 + rng.normal(0, 0.7, size=len(dates))
    s = pd.Series(y, index=dates)
    rep = calibrate_signal(s, template="default", target_outside_fraction=0.02, calibration_days=120)
    rec = rep.get("recommended_overrides", {})
    if "baseline.k" in rec:
        assert 1.5 <= float(rec["baseline.k"]) <= 6.0
