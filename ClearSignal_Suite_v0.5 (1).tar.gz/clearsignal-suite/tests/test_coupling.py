import numpy as np
import pandas as pd
from clearsignal_core.coupling import compute_coupling

def test_coupling_increase_detected():
    rng = np.random.default_rng(0)
    dates = pd.date_range("2025-01-01", periods=140, freq="D")

    # Baseline: mostly independent
    a = rng.normal(0, 1, size=140)
    b = rng.normal(0, 1, size=140)

    # Recent: add common factor to increase correlation
    common = rng.normal(0, 1, size=40)
    a[-40:] = a[-40:] + 0.9 * common
    b[-40:] = b[-40:] + 0.9 * common

    z = pd.DataFrame({"a": a, "b": b}, index=dates)
    cfg = {"baseline_days": 80, "gap_days": 7, "recent_days": 21, "threshold": 0.08, "watch_threshold": 0.05, "min_periods": 7}
    out = compute_coupling(z, cfg)
    assert np.isfinite(out["score"])
    assert out["delta"] > 0.05
