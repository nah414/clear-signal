import numpy as np
import pandas as pd
from clearsignal_core.baseline import compute_baseline
from clearsignal_core.deviation import compute_deviation
from clearsignal_core.drift import compute_drift

def test_drift_score_increases_on_shift():
    rng = np.random.default_rng(0)
    dates = pd.date_range("2025-01-01", periods=120, freq="D")
    vals = rng.normal(0, 0.2, size=120)
    vals[-20:] += 3.0
    s = pd.Series(vals, index=dates)
    b = compute_baseline(s, {"method": "static", "seasonality": "none", "k": 3.0})
    dev = compute_deviation(s, b)
    drift = compute_drift(dev, {"baseline_days": 60, "gap_days": 7, "recent_days": 14, "min_points": 10})
    assert np.isfinite(drift["score"])
    assert drift["score"] > 0.5
