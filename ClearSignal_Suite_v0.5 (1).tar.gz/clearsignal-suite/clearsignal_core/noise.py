from __future__ import annotations

from datetime import timedelta
from typing import Any, Dict

import numpy as np
import pandas as pd

def compute_noise(dev: pd.DataFrame, noise_cfg: Dict[str, Any]) -> Dict[str, Any]:
    baseline_days = int(noise_cfg.get("baseline_days", 60))
    gap_days = int(noise_cfg.get("gap_days", 7))
    recent_days = int(noise_cfg.get("recent_days", 21))
    min_points = int(noise_cfg.get("min_points", max(14, recent_days // 2)))
    eps = float(noise_cfg.get("eps", 1e-9))

    if len(dev.index) == 0:
        return {"score": float("nan"), "confidence": 0.0, "reason": "no data"}

    idx = dev.index
    end = idx.max()
    recent_start = end - timedelta(days=recent_days - 1)
    baseline_end = recent_start - timedelta(days=gap_days + 1)
    baseline_start = baseline_end - timedelta(days=baseline_days - 1)

    base_mask = (idx >= baseline_start) & (idx <= baseline_end)
    recent_mask = (idx >= recent_start) & (idx <= end)

    r_base = dev.loc[base_mask, "residual"].to_numpy(dtype=float)
    r_recent = dev.loc[recent_mask, "residual"].to_numpy(dtype=float)
    r_base = r_base[~np.isnan(r_base)]
    r_recent = r_recent[~np.isnan(r_recent)]

    n_base = int(r_base.size)
    n_recent = int(r_recent.size)
    if n_base < 3 or n_recent < 3:
        return {"score": float("nan"), "confidence": 0.0, "reason": "insufficient data", "n_base": n_base, "n_recent": n_recent}

    var_base = float(np.var(r_base))
    var_recent = float(np.var(r_recent))
    ratio = (var_recent + eps) / (var_base + eps)

    score = max(0.0, float(np.log(ratio)))  # only rising

    confidence = float(min(1.0, min(n_base, n_recent) / max(1, min_points)))

    return {
        "score": score,
        "confidence": confidence,
        "ratio": ratio,
        "var_base": var_base,
        "var_recent": var_recent,
        "window": {
            "baseline_start": baseline_start.date().isoformat(),
            "baseline_end": baseline_end.date().isoformat(),
            "recent_start": recent_start.date().isoformat(),
            "recent_end": end.date().isoformat(),
        },
    }
