from __future__ import annotations

from typing import Optional, Sequence

import pandas as pd

def read_csv(path: str) -> pd.DataFrame:
    return pd.read_csv(path)

def parse_timeseries_df(
    df: pd.DataFrame,
    ts_col: str,
    value_cols: Sequence[str],
    *,
    tz: Optional[str] = None,
) -> pd.DataFrame:
    if ts_col not in df.columns:
        raise ValueError(f"timestamp column '{ts_col}' not found")
    for c in value_cols:
        if c not in df.columns:
            raise ValueError(f"value column '{c}' not found")

    ts = pd.to_datetime(df[ts_col], errors="coerce", utc=True)
    keep = ~ts.isna()
    out = df.loc[keep, list(value_cols)].copy()
    out.index = ts.loc[keep]

    for c in value_cols:
        out[c] = pd.to_numeric(out[c], errors="coerce")

    if tz:
        out.index = out.index.tz_convert(tz)

    out = out[~out.index.duplicated(keep="last")]
    out = out.sort_index()
    return out

def read_csv_signal(path: str, ts_col: str, value_col: str, *, tz: Optional[str] = None) -> pd.Series:
    df = read_csv(path)
    out = parse_timeseries_df(df, ts_col, [value_col], tz=tz)
    return out[value_col]

def read_csv_system(path: str, ts_col: str, value_cols: Sequence[str], *, tz: Optional[str] = None) -> pd.DataFrame:
    df = read_csv(path)
    return parse_timeseries_df(df, ts_col, list(value_cols), tz=tz)
