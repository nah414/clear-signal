# JSON templates bundled as package data
