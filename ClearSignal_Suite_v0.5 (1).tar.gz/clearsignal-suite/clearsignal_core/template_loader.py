from __future__ import annotations

import json
from importlib import resources
from typing import Any, Dict

DEFAULT_TEMPLATE = "default"

def load_template(name: str) -> Dict[str, Any]:
    if not name:
        name = DEFAULT_TEMPLATE
    filename = f"{name}.json"
    try:
        with resources.files("clearsignal_core.templates").joinpath(filename).open("r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError as e:
        raise FileNotFoundError(f"Template '{name}' not found. Available: {list_available_templates()}") from e

def list_available_templates() -> list[str]:
    try:
        files = resources.files("clearsignal_core.templates").iterdir()
        names = []
        for p in files:
            if p.name.endswith(".json") and not p.name.startswith("_"):
                names.append(p.name[:-5])
        return sorted(names)
    except Exception:
        return []

def apply_overrides(config: Dict[str, Any], overrides: Dict[str, str]) -> Dict[str, Any]:
    cfg = json.loads(json.dumps(config))
    for path, raw in overrides.items():
        keys = path.split(".")
        cur = cfg
        for k in keys[:-1]:
            if k not in cur or not isinstance(cur[k], dict):
                cur[k] = {}
            cur = cur[k]
        cur[keys[-1]] = _coerce(raw)
    return cfg

def _coerce(raw: str) -> Any:
    s = raw.strip()
    if s.lower() in {"true", "false"}:
        return s.lower() == "true"
    try:
        if "." in s:
            return float(s)
        return int(s)
    except ValueError:
        return s
