from __future__ import annotations

from datetime import timedelta
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

from .utils import ks_statistic, linear_trend_slope


def _estimate_change_point(
    z: pd.Series,
    *,
    min_seg: int = 10,
    candidate_start: Optional[pd.Timestamp] = None,
    candidate_end: Optional[pd.Timestamp] = None,
) -> Dict[str, Any]:
    """Estimate a single change point by scanning split points.

    Heuristic: find the split index i that maximizes |median(z[:i]) - median(z[i:])|.
    Returns:
      {"change_point": "YYYY-MM-DD" or None, "change_score": float}
    """
    if z is None or len(z.index) == 0:
        return {"change_point": None, "change_score": float("nan")}

    zz = z.dropna().astype(float)
    if candidate_start is not None:
        zz = zz.loc[zz.index >= candidate_start]
    if candidate_end is not None:
        zz = zz.loc[zz.index <= candidate_end]

    if len(zz) < 2 * max(3, min_seg):
        return {"change_point": None, "change_score": float("nan")}

    arr = zz.to_numpy(dtype=float)
    idx = zz.index

    best_i = None
    best_score = -1.0
    n = len(arr)
    min_seg = max(3, int(min_seg))

    for i in range(min_seg, n - min_seg):
        left = arr[:i]
        right = arr[i:]
        if left.size < min_seg or right.size < min_seg:
            continue
        med_left = float(np.median(left))
        med_right = float(np.median(right))
        score = abs(med_right - med_left)
        if score > best_score:
            best_score = score
            best_i = i

    if best_i is None:
        return {"change_point": None, "change_score": float("nan")}

    cp = idx[best_i].date().isoformat()
    return {"change_point": cp, "change_score": float(best_score)}


def compute_drift(dev: pd.DataFrame, drift_cfg: Dict[str, Any]) -> Dict[str, Any]:
    baseline_days = int(drift_cfg.get("baseline_days", 60))
    gap_days = int(drift_cfg.get("gap_days", 7))
    recent_days = int(drift_cfg.get("recent_days", 14))
    min_points = int(drift_cfg.get("min_points", max(14, recent_days // 2)))
    eps = float(drift_cfg.get("eps", 1e-9))

    if len(dev.index) == 0:
        return {"score": float("nan"), "confidence": 0.0, "reason": "no data"}

    idx = dev.index
    end = idx.max()
    recent_start = end - timedelta(days=recent_days - 1)
    baseline_end = recent_start - timedelta(days=gap_days + 1)
    baseline_start = baseline_end - timedelta(days=baseline_days - 1)

    base_mask = (idx >= baseline_start) & (idx <= baseline_end)
    recent_mask = (idx >= recent_start) & (idx <= end)

    z_base = dev.loc[base_mask, "z"].to_numpy(dtype=float)
    z_recent = dev.loc[recent_mask, "z"].to_numpy(dtype=float)
    z_base = z_base[~np.isnan(z_base)]
    z_recent = z_recent[~np.isnan(z_recent)]

    n_base = int(z_base.size)
    n_recent = int(z_recent.size)

    if n_base < 3 or n_recent < 3:
        return {
            "score": float("nan"),
            "confidence": 0.0,
            "reason": "insufficient data",
            "n_base": n_base,
            "n_recent": n_recent,
            "window": {
                "baseline_start": baseline_start.date().isoformat(),
                "baseline_end": baseline_end.date().isoformat(),
                "recent_start": recent_start.date().isoformat(),
                "recent_end": end.date().isoformat(),
            },
        }

    med_base = float(np.median(z_base))
    med_recent = float(np.median(z_recent))
    median_shift = abs(med_recent - med_base)

    var_base = float(np.var(z_base))
    var_recent = float(np.var(z_recent))
    var_ratio = (var_recent + eps) / (var_base + eps)
    var_change = abs(np.log(var_ratio))

    ks = ks_statistic(z_base, z_recent)

    absz_recent = np.abs(dev.loc[recent_mask, "z"].to_numpy(dtype=float))
    trend = linear_trend_slope(absz_recent)
    trend = 0.0 if not np.isfinite(trend) else abs(trend)

    # Change-point hinting (optional)
    lookback = int(drift_cfg.get("change_point_lookback_days", 28))
    min_after = int(drift_cfg.get("change_point_min_after_days", 7))
    min_seg = int(drift_cfg.get("change_point_min_segment", 10))

    z_window = dev.loc[(idx >= baseline_start) & (idx <= end), "z"]
    candidate_start = max(baseline_start, baseline_end - timedelta(days=lookback))
    candidate_end = end - timedelta(days=min_after)
    cp = _estimate_change_point(z_window, min_seg=min_seg, candidate_start=candidate_start, candidate_end=candidate_end)

    w = drift_cfg.get("weights", {"median_shift": 0.7, "var_change": 0.3, "ks": 0.4, "trend": 0.2})
    score = (
        float(w.get("median_shift", 0.7)) * median_shift +
        float(w.get("var_change", 0.3)) * var_change +
        float(w.get("ks", 0.4)) * (ks if np.isfinite(ks) else 0.0) +
        float(w.get("trend", 0.2)) * trend
    )

    confidence = float(min(1.0, min(n_base, n_recent) / max(1, min_points)))

    return {
        "score": float(score),
        "confidence": confidence,
        "n_base": n_base,
        "n_recent": n_recent,
        "median_shift": median_shift,
        "var_ratio": var_ratio,
        "ks": ks,
        "absz_trend": trend,
        "change_point": cp.get("change_point"),
        "change_score": cp.get("change_score"),
        "window": {
            "baseline_start": baseline_start.date().isoformat(),
            "baseline_end": baseline_end.date().isoformat(),
            "recent_start": recent_start.date().isoformat(),
            "recent_end": end.date().isoformat(),
        },
    }
