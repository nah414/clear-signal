from __future__ import annotations

from dataclasses import dataclass, asdict, field
from datetime import date
from typing import Any, Dict, List, Optional, Literal

Status = Literal["stable", "watch", "drift"]
AlertType = Literal["baseline_break", "drift", "recovery_slowing", "noise_rising", "data_quality", "coupling_increase"]

@dataclass(frozen=True)
class AnnotationInterval:
    start: date
    end: date
    label: str = ""

@dataclass(frozen=True)
class SignalSpec:
    name: str
    unit: str = ""
    directionality: Literal["higher_is_better", "lower_is_better", "neutral"] = "neutral"
    cadence: Literal["daily", "hourly", "irregular"] = "daily"

@dataclass
class EvidenceBundle:
    ts: List[str] = field(default_factory=list)
    value: List[Optional[float]] = field(default_factory=list)
    expected: List[Optional[float]] = field(default_factory=list)
    lower: List[Optional[float]] = field(default_factory=list)
    upper: List[Optional[float]] = field(default_factory=list)
    z: List[Optional[float]] = field(default_factory=list)

    window_start: Optional[str] = None
    window_end: Optional[str] = None
    annotations: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class Alert:
    type: AlertType
    status: Status
    score: float
    confidence: float
    title: str
    message: str
    signal_name: str
    created_at: str
    evidence: EvidenceBundle

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["evidence"] = self.evidence.to_dict()
        return d

@dataclass
class SignalReport:
    signal: SignalSpec
    status: Status
    summary: Dict[str, Any]
    alerts: List[Alert]
    series: Dict[str, Any]
    config_used: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "signal": asdict(self.signal),
            "status": self.status,
            "summary": self.summary,
            "alerts": [a.to_dict() for a in self.alerts],
            "series": self.series,
            "config_used": self.config_used,
        }

@dataclass
class SystemReport:
    system_name: str
    status: Status
    summary: Dict[str, Any]
    signal_reports: List[SignalReport]
    alerts: List[Alert]
    config_used: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "system_name": self.system_name,
            "status": self.status,
            "summary": self.summary,
            "signals": [sr.to_dict() for sr in self.signal_reports],
            "alerts": [a.to_dict() for a in self.alerts],
            "config_used": self.config_used,
        }
