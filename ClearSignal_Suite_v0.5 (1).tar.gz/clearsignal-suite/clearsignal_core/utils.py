from __future__ import annotations

import numpy as np
import pandas as pd

MAD_SCALE = 1.4826  # approx MAD -> sigma for Normal

def nanmedian(x: np.ndarray) -> float:
    x = x[~np.isnan(x)]
    if x.size == 0:
        return float("nan")
    return float(np.median(x))

def mad(x: np.ndarray) -> float:
    x = x[~np.isnan(x)]
    if x.size == 0:
        return float("nan")
    m = np.median(x)
    return float(np.median(np.abs(x - m)))

def robust_scale(x: np.ndarray, eps: float = 1e-9) -> float:
    m = mad(x)
    if not np.isfinite(m) or m < eps:
        return eps
    return float(MAD_SCALE * m)

def ks_statistic(x: np.ndarray, y: np.ndarray) -> float:
    x = x[~np.isnan(x)]
    y = y[~np.isnan(y)]
    if x.size == 0 or y.size == 0:
        return float("nan")
    x = np.sort(x)
    y = np.sort(y)
    data_all = np.sort(np.concatenate([x, y]))
    cdf_x = np.searchsorted(x, data_all, side="right") / x.size
    cdf_y = np.searchsorted(y, data_all, side="right") / y.size
    return float(np.max(np.abs(cdf_x - cdf_y)))

def linear_trend_slope(y: np.ndarray) -> float:
    y = np.asarray(y, dtype=float)
    mask = ~np.isnan(y)
    if mask.sum() < 3:
        return float("nan")
    yy = y[mask]
    x = np.arange(len(y), dtype=float)[mask]
    x = x - x.mean()
    yy = yy - yy.mean()
    denom = float(np.dot(x, x))
    if denom <= 0:
        return float("nan")
    return float(np.dot(x, yy) / denom)

def rolling_median(series: pd.Series, window: int, min_periods: int) -> pd.Series:
    return series.rolling(window=window, min_periods=min_periods).median()

def rolling_mad(series: pd.Series, window: int, min_periods: int) -> pd.Series:
    def _mad(arr: np.ndarray) -> float:
        arr = arr.astype(float)
        arr = arr[~np.isnan(arr)]
        if arr.size == 0:
            return np.nan
        m = np.median(arr)
        return float(np.median(np.abs(arr - m)))
    return series.rolling(window=window, min_periods=min_periods).apply(_mad, raw=True)
