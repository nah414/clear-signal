from __future__ import annotations

import argparse
import json
import sys
from typing import Dict, List, Optional

from .ingest import read_csv_signal, read_csv_system
from .report import analyze_signal, analyze_system
from .calibrate import calibrate_signal
from .template_loader import list_available_templates

def _parse_overrides(pairs: List[str]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for p in pairs:
        if "=" not in p:
            raise ValueError(f"override must be key=value, got: {p}")
        k, v = p.split("=", 1)
        out[k.strip()] = v.strip()
    return out

def _write(obj, out_path: Optional[str]) -> None:
    text = json.dumps(obj, indent=2, sort_keys=False)
    if out_path:
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(text)
    else:
        sys.stdout.write(text + "\n")

def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(prog="clearsignal", description="ClearSignal core engine CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("templates", help="List available templates")

    p_an = sub.add_parser("analyze", help="Analyze a single signal from CSV")
    p_an.add_argument("--csv", required=True)
    p_an.add_argument("--ts", required=True)
    p_an.add_argument("--value", required=True)
    p_an.add_argument("--name", default=None)
    p_an.add_argument("--unit", default="")
    p_an.add_argument("--template", default="default")
    p_an.add_argument("--agg", default="median", choices=["mean", "sum", "median", "last"])
    p_an.add_argument("--set", action="append", default=[])
    p_an.add_argument("--annotations", default=None)
    p_an.add_argument("--exclude-annotated-from-baseline", action="store_true")
    p_an.add_argument("--out", default=None)

    p_sys = sub.add_parser("analyze-system", help="Analyze multiple signals (system) from CSV")
    p_sys.add_argument("--csv", required=True)
    p_sys.add_argument("--ts", required=True)
    p_sys.add_argument("--values", nargs="+", required=True)
    p_sys.add_argument("--system-name", required=True)
    p_sys.add_argument("--template", default="default")
    p_sys.add_argument("--agg", default="median", choices=["mean", "sum", "median", "last"])
    p_sys.add_argument("--set", action="append", default=[])
    p_sys.add_argument("--annotations", default=None)
    p_sys.add_argument("--exclude-annotated-from-baseline", action="store_true")
    p_sys.add_argument("--out", default=None)


    p_cal = sub.add_parser("calibrate", help="Calibrate thresholds from your own history")
    p_cal.add_argument("--csv", required=True)
    p_cal.add_argument("--ts", required=True)
    p_cal.add_argument("--value", required=True)
    p_cal.add_argument("--template", default="default")
    p_cal.add_argument("--agg", default="median", choices=["mean", "sum", "median", "last"])
    p_cal.add_argument("--set", action="append", default=[])
    p_cal.add_argument("--target-outside", type=float, default=0.02, help="Target fraction outside baseline band (on baseline window)")
    p_cal.add_argument("--target-drift", type=float, default=0.05, help="Target fraction of backtest windows triggering drift")
    p_cal.add_argument("--target-noise", type=float, default=0.05, help="Target fraction of backtest windows triggering noise")
    p_cal.add_argument("--calibration-days", type=int, default=180)
    p_cal.add_argument("--out", default=None)

    args = parser.parse_args(argv)

    if args.cmd == "templates":
        print("\n".join(list_available_templates()))
        return 0

    overrides = _parse_overrides(args.set)

    if args.cmd == "analyze":
        s = read_csv_signal(args.csv, args.ts, args.value)
        rep = analyze_signal(
            s,
            signal_name=(args.name or args.value),
            unit=args.unit,
            template=args.template,
            overrides=(overrides or None),
            annotations_path=args.annotations,
            exclude_annotated_from_baseline=args.exclude_annotated_from_baseline,
            agg=args.agg,
        ).to_dict()
        _write(rep, args.out)
        return 0

    if args.cmd == "analyze-system":
        df = read_csv_system(args.csv, args.ts, args.values)
        rep = analyze_system(
            df,
            system_name=args.system_name,
            template=args.template,
            overrides=(overrides or None),
            annotations_path=args.annotations,
            exclude_annotated_from_baseline=args.exclude_annotated_from_baseline,
            agg=args.agg,
        ).to_dict()
        _write(rep, args.out)
        return 0

    if args.cmd == "calibrate":
        s = read_csv_signal(args.csv, args.ts, args.value)
        rep = calibrate_signal(
            s,
            template=args.template,
            overrides=(overrides or None),
            agg=args.agg,
            target_outside_fraction=float(args.target_outside),
            target_drift_fraction=float(args.target_drift),
            target_noise_fraction=float(args.target_noise),
            calibration_days=int(args.calibration_days),
        )
        _write(rep, args.out)
        return 0

    parser.print_help()
    return 2

if __name__ == "__main__":
    raise SystemExit(main())
