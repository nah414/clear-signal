const apiKeyInput = document.getElementById('apiKey');
const saveKeyBtn = document.getElementById('saveKey');
const keyStatus = document.getElementById('keyStatus');

const csvFile = document.getElementById('csvFile');
const mode = document.getElementById('mode');
const tsCol = document.getElementById('tsCol');
const valueCol = document.getElementById('valueCol');
const valuesCols = document.getElementById('valuesCols');
const systemName = document.getElementById('systemName');
const template = document.getElementById('template');
const store = document.getElementById('store');
const analyzeBtn = document.getElementById('analyzeBtn');
const analyzeOut = document.getElementById('analyzeOut');

const reportsTable = document.getElementById('reportsTable');
const refreshReports = document.getElementById('refreshReports');
const reportsStatus = document.getElementById('reportsStatus');

const jobName = document.getElementById('jobName');
const intervalMin = document.getElementById('intervalMin');
const webhook = document.getElementById('webhook');
const createJobBtn = document.getElementById('createJobBtn');
const refreshJobs = document.getElementById('refreshJobs');
const jobsTable = document.getElementById('jobsTable');
const jobsStatus = document.getElementById('jobsStatus');

function getApiKey() {
  return localStorage.getItem('CLEAR_API_KEY') || '';
}
function setApiKey(k) {
  localStorage.setItem('CLEAR_API_KEY', k || '');
}
function authHeaders() {
  const k = getApiKey();
  return k ? {'X-API-Key': k} : {};
}

function setKeyStatus(msg) { keyStatus.textContent = msg || ''; }

function syncKeyUI() {
  apiKeyInput.value = getApiKey();
  setKeyStatus(getApiKey() ? 'saved' : '');
}
syncKeyUI();

saveKeyBtn.addEventListener('click', () => {
  setApiKey(apiKeyInput.value.trim());
  syncKeyUI();
});

mode.addEventListener('change', () => {
  const isSys = mode.value === 'system';
  valueCol.style.display = isSys ? 'none' : '';
  valuesCols.style.display = isSys ? '' : 'none';
  systemName.style.display = isSys ? '' : 'none';
});
mode.dispatchEvent(new Event('change'));

async function apiGet(path) {
  const res = await fetch(path, {headers: authHeaders()});
  if (!res.ok) throw new Error(`${res.status} ${await res.text()}`);
  return await res.json();
}

async function apiPostForm(path, formData) {
  const res = await fetch(path, {method:'POST', headers: authHeaders(), body: formData});
  if (!res.ok) throw new Error(`${res.status} ${await res.text()}`);
  return await res.json();
}

async function loadTemplates() {
  try {
    const data = await apiGet('/templates');
    template.innerHTML = '';
    (data.templates || []).forEach(t => {
      const opt = document.createElement('option');
      opt.value = t;
      opt.textContent = t;
      template.appendChild(opt);
    });
    template.value = 'default';
  } catch (e) {
    template.innerHTML = '<option value="default">default</option>';
  }
}

async function refreshReportsList() {
  reportsStatus.textContent = 'loading…';
  try {
    const data = await apiGet('/reports?limit=50');
    const rows = (data.reports || []);
    reportsTable.innerHTML = '';
    rows.forEach(r => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${escapeHtml(r.created_at || '')}</td>
        <td>${escapeHtml(r.kind || '')}</td>
        <td>${escapeHtml(r.system_name || '')}</td>
        <td><code>${escapeHtml(r.id || '')}</code></td>
        <td><a href="/ui/view.html?id=${encodeURIComponent(r.id)}">open</a></td>
      `;
      reportsTable.appendChild(tr);
    });
    reportsStatus.textContent = `${rows.length} report(s)`;
  } catch (e) {
    reportsStatus.textContent = 'error';
    console.error(e);
  }
}

async function refreshJobsList() {
  jobsStatus.textContent = 'loading…';
  try {
    const data = await apiGet('/jobs?limit=50');
    const rows = (data.jobs || []);
    jobsTable.innerHTML = '';
    rows.forEach(j => {
      const tr = document.createElement('tr');
      const runBtnId = `run_${j.id}`;
      tr.innerHTML = `
        <td>${escapeHtml(j.name || '')}</td>
        <td>${escapeHtml(j.kind || '')}</td>
        <td>${escapeHtml(String(j.interval_minutes || ''))}</td>
        <td>${escapeHtml(j.next_run_at || '')}</td>
        <td>${escapeHtml(j.last_run_at || '')}</td>
        <td>${escapeHtml(j.last_status || '')}</td>
        <td><code>${escapeHtml(j.id || '')}</code></td>
        <td>
          <button class="secondary" id="${runBtnId}">run now</button>
          ${j.last_report_id ? `<a style="margin-left:10px" href="/ui/view.html?id=${encodeURIComponent(j.last_report_id)}">last report</a>` : ''}
        </td>
      `;
      jobsTable.appendChild(tr);
      setTimeout(() => {
        const btn = document.getElementById(runBtnId);
        if (btn) btn.addEventListener('click', async () => {
          btn.disabled = true;
          try {
            const out = await apiPostForm(`/jobs/${encodeURIComponent(j.id)}/run`, new FormData());
            await refreshJobsList();
            await refreshReportsList();
            alert(`Job ran. Report: ${out.report_id}`);
          } catch (e) {
            alert(String(e));
          } finally {
            btn.disabled = false;
          }
        });
      }, 0);
    });
    jobsStatus.textContent = `${rows.length} job(s)`;
  } catch (e) {
    jobsStatus.textContent = 'error';
    console.error(e);
  }
}

refreshReports.addEventListener('click', refreshReportsList);
refreshJobs.addEventListener('click', refreshJobsList);

analyzeBtn.addEventListener('click', async () => {
  analyzeOut.textContent = '';
  const f = csvFile.files[0];
  if (!f) {
    analyzeOut.textContent = 'Choose a CSV first.';
    return;
  }
  analyzeBtn.disabled = true;
  try {
    const fd = new FormData();
    fd.append('csv', f);
    fd.append('ts', tsCol.value.trim());
    fd.append('template', template.value);
    fd.append('store', store.checked ? 'true' : 'false');

    if (mode.value === 'signal') {
      fd.append('value', valueCol.value.trim());
      const res = await apiPostForm('/analyze', fd);
      analyzeOut.textContent = JSON.stringify(res, null, 2);
      if (res.report_id) {
        await refreshReportsList();
        window.open(`/ui/view.html?id=${encodeURIComponent(res.report_id)}`, '_blank');
      }
    } else {
      fd.append('values', valuesCols.value.trim());
      fd.append('system_name', systemName.value.trim());
      const res = await apiPostForm('/analyze-system', fd);
      analyzeOut.textContent = JSON.stringify(res, null, 2);
      if (res.report_id) {
        await refreshReportsList();
        window.open(`/ui/view.html?id=${encodeURIComponent(res.report_id)}`, '_blank');
      }
    }
  } catch (e) {
    analyzeOut.textContent = String(e);
  } finally {
    analyzeBtn.disabled = false;
  }
});

createJobBtn.addEventListener('click', async () => {
  const f = csvFile.files[0];
  if (!f) {
    alert('Choose a CSV first (job stores the CSV).');
    return;
  }
  createJobBtn.disabled = true;
  try {
    const fd = new FormData();
    fd.append('csv', f);
    fd.append('name', jobName.value.trim() || 'job');
    fd.append('kind', mode.value);
    fd.append('ts', tsCol.value.trim());
    fd.append('template', template.value);
    fd.append('interval_minutes', String(parseInt(intervalMin.value || '1440', 10)));
    if (webhook.value.trim()) fd.append('webhook_url', webhook.value.trim());

    if (mode.value === 'signal') {
      fd.append('value', valueCol.value.trim());
    } else {
      fd.append('values', valuesCols.value.trim());
      fd.append('system_name', systemName.value.trim());
    }

    const res = await apiPostForm('/jobs', fd);
    alert(`Created job: ${res.job_id}`);
    await refreshJobsList();
  } catch (e) {
    alert(String(e));
  } finally {
    createJobBtn.disabled = false;
  }
});

function escapeHtml(s) {
  return String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}

loadTemplates().then(() => {
  refreshReportsList();
  refreshJobsList();
});
