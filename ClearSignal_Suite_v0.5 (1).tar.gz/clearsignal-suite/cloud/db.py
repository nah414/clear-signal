from __future__ import annotations

import json
import os
import sqlite3
import uuid
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from clearsignal_core.ingest import parse_timeseries_df
from clearsignal_core.report import analyze_signal, analyze_system


def _now() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def db_path() -> str:
    return os.environ.get("CLEAR_DB", ":memory:")


def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(db_path())
    conn.row_factory = sqlite3.Row
    init_db(conn)
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS reports (
          id TEXT PRIMARY KEY,
          created_at TEXT NOT NULL,
          kind TEXT NOT NULL,
          system_name TEXT,
          report_json TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS jobs (
          id TEXT PRIMARY KEY,
          created_at TEXT NOT NULL,
          name TEXT NOT NULL,
          kind TEXT NOT NULL,
          system_name TEXT,
          ts_col TEXT NOT NULL,
          value_cols_json TEXT NOT NULL,
          template TEXT NOT NULL,
          overrides_json TEXT,
          agg TEXT NOT NULL,
          exclude_annotated INTEGER NOT NULL,
          interval_minutes INTEGER NOT NULL,
          next_run_at TEXT NOT NULL,
          webhook_url TEXT,
          csv_bytes BLOB NOT NULL,
          enabled INTEGER NOT NULL,
          last_run_at TEXT,
          last_report_id TEXT,
          last_status TEXT
        )
        """
    )
    conn.commit()


def store_report(conn: sqlite3.Connection, *, kind: str, system_name: str, report: Dict[str, Any]) -> str:
    rid = str(uuid.uuid4())
    conn.execute(
        "INSERT INTO reports (id, created_at, kind, system_name, report_json) VALUES (?, ?, ?, ?, ?)",
        (rid, _now(), kind, system_name, json.dumps(report)),
    )
    conn.commit()
    return rid


def list_reports(conn: sqlite3.Connection, *, limit: int = 50) -> List[Dict[str, Any]]:
    rows = conn.execute(
        "SELECT id, created_at, kind, system_name FROM reports ORDER BY created_at DESC LIMIT ?",
        (int(limit),),
    ).fetchall()
    return [dict(r) for r in rows]


def get_report(conn: sqlite3.Connection, report_id: str) -> Optional[Dict[str, Any]]:
    row = conn.execute("SELECT report_json FROM reports WHERE id = ?", (report_id,)).fetchone()
    if row is None:
        return None
    return json.loads(row["report_json"])


def _parse_value_cols(kind: str, value: Optional[str], values: Optional[str]) -> List[str]:
    if kind == "signal":
        if not value:
            raise ValueError("value column is required for kind=signal")
        return [value.strip()]
    # system
    if not values:
        raise ValueError("values columns are required for kind=system")
    cols = [c for c in values.replace(",", " ").split() if c.strip()]
    if len(cols) < 2:
        raise ValueError("system job requires at least 2 value columns")
    return cols


def create_job(
    conn: sqlite3.Connection,
    *,
    name: str,
    kind: str,
    system_name: str,
    ts_col: str,
    value_cols: List[str],
    template: str,
    overrides: Optional[Dict[str, Any]],
    agg: str,
    exclude_annotated: bool,
    interval_minutes: int,
    webhook_url: Optional[str],
    csv_bytes: bytes,
) -> Dict[str, Any]:
    if kind not in {"signal", "system"}:
        raise ValueError("kind must be 'signal' or 'system'")
    jid = str(uuid.uuid4())
    next_run = (datetime.utcnow() + timedelta(minutes=int(interval_minutes))).replace(microsecond=0).isoformat() + "Z"
    conn.execute(
        """
        INSERT INTO jobs (
          id, created_at, name, kind, system_name, ts_col, value_cols_json, template, overrides_json,
          agg, exclude_annotated, interval_minutes, next_run_at, webhook_url, csv_bytes, enabled,
          last_run_at, last_report_id, last_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            jid,
            _now(),
            name,
            kind,
            system_name,
            ts_col,
            json.dumps(value_cols),
            template,
            json.dumps(overrides) if overrides else None,
            agg,
            1 if exclude_annotated else 0,
            int(interval_minutes),
            next_run,
            webhook_url,
            sqlite3.Binary(csv_bytes),
            1,
            None,
            None,
            None,
        ),
    )
    conn.commit()
    return {"job_id": jid, "next_run_at": next_run}


def list_jobs(conn: sqlite3.Connection, *, limit: int = 50) -> List[Dict[str, Any]]:
    rows = conn.execute(
        """
        SELECT id, created_at, name, kind, system_name, interval_minutes, next_run_at, enabled,
               last_run_at, last_report_id, last_status
        FROM jobs
        ORDER BY created_at DESC
        LIMIT ?
        """,
        (int(limit),),
    ).fetchall()
    return [dict(r) for r in rows]


def get_job(conn: sqlite3.Connection, job_id: str) -> Optional[Dict[str, Any]]:
    row = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
    return dict(row) if row else None


def due_jobs(conn: sqlite3.Connection, *, now_iso: Optional[str] = None, limit: int = 10) -> List[Dict[str, Any]]:
    now_iso = now_iso or _now()
    rows = conn.execute(
        """
        SELECT id, next_run_at
        FROM jobs
        WHERE enabled = 1 AND next_run_at <= ?
        ORDER BY next_run_at ASC
        LIMIT ?
        """,
        (now_iso, int(limit)),
    ).fetchall()
    return [dict(r) for r in rows]


def _compute_next_run(interval_minutes: int) -> str:
    return (datetime.utcnow() + timedelta(minutes=int(interval_minutes))).replace(microsecond=0).isoformat() + "Z"


def _send_webhook(url: str, payload: Dict[str, Any]) -> Tuple[bool, str]:
    # Standard library only (no requests dependency).
    import urllib.request

    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return True, f"{resp.status}"
    except Exception as e:
        return False, str(e)


def run_job(conn: sqlite3.Connection, job_id: str, *, run_even_if_disabled: bool = False) -> Dict[str, Any]:
    job = get_job(conn, job_id)
    if not job:
        raise ValueError("job not found")
    if not run_even_if_disabled and int(job.get("enabled") or 0) != 1:
        raise ValueError("job is disabled")

    kind = str(job["kind"])
    system_name = str(job.get("system_name") or "")
    ts_col = str(job["ts_col"])
    value_cols = json.loads(job["value_cols_json"])
    template = str(job["template"])
    overrides = json.loads(job["overrides_json"]) if job.get("overrides_json") else None
    agg = str(job.get("agg") or "median")
    exclude_annotated = bool(int(job.get("exclude_annotated") or 0))
    interval_minutes = int(job.get("interval_minutes") or 1440)
    webhook_url = job.get("webhook_url")

    csv_bytes = job["csv_bytes"]
    from io import BytesIO
    df = pd.read_csv(BytesIO(csv_bytes))

    ts_df = parse_timeseries_df(df, ts_col, value_cols)

    if kind == "signal":
        series = ts_df[value_cols[0]]
        report = analyze_signal(
            series,
            signal_name=value_cols[0],
            template=template,
            overrides=overrides,
            agg=agg,
            exclude_annotated_from_baseline=exclude_annotated,
        ).to_dict()
        rep_kind = "signal"
        rep_system = value_cols[0]
        last_status = str(report.get("status") or "")
    else:
        report = analyze_system(
            ts_df,
            system_name=(system_name or "System"),
            template=template,
            overrides=overrides,
            agg=agg,
            exclude_annotated_from_baseline=exclude_annotated,
        ).to_dict()
        rep_kind = "system"
        rep_system = system_name or "System"
        last_status = str(report.get("status") or "")

    report_id = store_report(conn, kind=rep_kind, system_name=rep_system, report=report)

    next_run_at = _compute_next_run(interval_minutes)
    conn.execute(
        """
        UPDATE jobs
        SET last_run_at = ?, last_report_id = ?, last_status = ?, next_run_at = ?
        WHERE id = ?
        """,
        (_now(), report_id, last_status, next_run_at, job_id),
    )
    conn.commit()

    webhook_result = None
    if webhook_url:
        ok, detail = _send_webhook(str(webhook_url), {"job_id": job_id, "report_id": report_id, "status": last_status, "system_name": rep_system, "kind": rep_kind, "created_at": _now()})
        webhook_result = {"ok": ok, "detail": detail}

    return {"job_id": job_id, "report_id": report_id, "next_run_at": next_run_at, "status": last_status, "webhook": webhook_result}


def set_job_enabled(conn: sqlite3.Connection, job_id: str, enabled: bool) -> None:
    conn.execute("UPDATE jobs SET enabled = ? WHERE id = ?", (1 if enabled else 0, job_id))
    conn.commit()
