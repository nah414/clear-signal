from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

# Ensure repo root is importable even when running this file directly.
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from cloud.db import connect, due_jobs, run_job  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description="ClearSignal worker: runs scheduled jobs from SQLite.")
    ap.add_argument("--poll-seconds", type=int, default=30, help="How often to check for due jobs (default: 30)")
    ap.add_argument("--once", action="store_true", help="Run due jobs once and exit")
    ap.add_argument("--limit", type=int, default=10, help="Max due jobs per poll (default: 10)")
    ap.add_argument("--job", type=str, default=None, help="Run a specific job ID once and exit")
    args = ap.parse_args()

    if args.job:
        conn = connect()
        out = run_job(conn, args.job, run_even_if_disabled=True)
        print(out)
        conn.close()
        return 0

    while True:
        conn = connect()
        jobs = due_jobs(conn, limit=args.limit)
        if jobs:
            for j in jobs:
                jid = j["id"]
                try:
                    out = run_job(conn, jid)
                    print("ran job", jid, "-> report", out.get("report_id"), "status", out.get("status"))
                except Exception as e:
                    print("job failed", jid, "error", e)
        conn.close()

        if args.once:
            return 0
        time.sleep(max(5, int(args.poll_seconds)))


if __name__ == "__main__":
    raise SystemExit(main())
