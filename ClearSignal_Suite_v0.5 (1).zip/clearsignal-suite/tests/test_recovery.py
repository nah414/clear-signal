import numpy as np
import pandas as pd
from clearsignal_core.baseline import compute_baseline
from clearsignal_core.deviation import compute_deviation
from clearsignal_core.recovery import compute_recovery

def test_recovery_detects_events():
    dates = pd.date_range("2025-01-01", periods=120, freq="D")
    vals = np.zeros(120, dtype=float)
    vals[40] = -5
    vals[41] = 0
    vals[100] = -5
    vals[101] = -3
    vals[102] = -2
    vals[103] = 0
    s = pd.Series(vals, index=dates, dtype=float)
    b = compute_baseline(s, {"method": "static", "seasonality": "none", "k": 3.0})
    dev = compute_deviation(s, b)
    rec = compute_recovery(dev, {"shock_z": 2.0, "recover_z": 1.0, "baseline_days": 80, "gap_days": 0, "recent_days": 20, "min_shocks": 1})
    assert "events_preview" in rec
