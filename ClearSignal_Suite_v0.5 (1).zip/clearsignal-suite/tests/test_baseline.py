import numpy as np
import pandas as pd
from clearsignal_core.baseline import compute_baseline

def test_static_weekly_baseline_uses_weekday_buckets():
    dates = pd.date_range("2025-01-01", periods=70, freq="D")
    values = [d.weekday() + 1 for d in dates]
    s = pd.Series(values, index=dates, dtype=float)
    cfg = {"method": "static", "seasonality": "weekly", "k": 3.0, "min_points_per_bucket": 5}
    b = compute_baseline(s, cfg)
    assert np.allclose(b["expected"].to_numpy(), s.to_numpy(), atol=1e-9)
