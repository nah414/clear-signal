import json
from pathlib import Path
import subprocess
import sys

def test_cli_templates():
    result = subprocess.run([sys.executable, "-m", "clearsignal_core.cli", "templates"], capture_output=True, text=True)
    assert result.returncode == 0
    out = result.stdout.strip().splitlines()
    assert "default" in out

def test_cli_analyze(tmp_path: Path):
    sample = Path("sample_data") / "sleep_example.csv"
    out = tmp_path / "report.json"
    result = subprocess.run([
        sys.executable, "-m", "clearsignal_core.cli", "analyze",
        "--csv", str(sample),
        "--ts", "date",
        "--value", "sleep_hours",
        "--template", "recovery",
        "--out", str(out),
    ], capture_output=True, text=True)
    assert result.returncode == 0
    data = json.loads(out.read_text(encoding="utf-8"))
    assert "status" in data and "series" in data
