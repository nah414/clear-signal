# Demos

Pre-generated outputs are stored in `demos/output/`.

Regenerate:
```bash
make demo
```
