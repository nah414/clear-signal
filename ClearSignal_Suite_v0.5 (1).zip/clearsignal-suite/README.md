# ClearSignal Suite

ClearSignal is a **local-first**, explainable early-warning engine for time-series “systems”
(sleep/recovery, cashflow, operations, etc.).

It does **not** do medical diagnosis or “AI prophecy.” It does:
- robust baseline bands (median + MAD)
- deviation (robust z-score)
- drift (distribution shift between baseline and recent windows)
- recovery slowing (shocks take longer to settle)
- noise rising (variance rising in residuals)
- system coupling (signals start moving together more than usual)
- calibration (set thresholds from *your own* history)

This repo is a full starter kit:
- `clearsignal_core/` : the engine + CLI
- `viewer/` : a zero-dependency HTML viewer for report JSON (offline-friendly)
- `cloud/` : a deployable FastAPI API **plus a tiny web UI** (`/ui/`) and a simple worker for scheduled jobs

---

## Install (engine + CLI)

```bash
python -m pip install -e ".[dev]"
pytest -q
```

List templates:

```bash
clearsignal templates
```

---

## Run demos

```bash
make demo
```

Outputs will be written under `demos/output/`.

View reports (offline):
- open `viewer/index.html`
- load a `*_report.json`

---

## Run ClearSignal Cloud (API + Web UI)

```bash
pip install -r cloud/requirements.txt
make cloud
```

Open:
- UI: `http://localhost:8000/ui/`
- API docs: `http://localhost:8000/docs`

Cloud endpoints:
- `POST /analyze` (single signal from CSV upload)
- `POST /analyze-system` (multi-signal system)
- `POST /calibrate` (recommend thresholds from your history)
- `GET /reports` / `GET /reports/{id}` (optional persistence in SQLite)

Persistence:
- set `CLEAR_DB=clearsignal.db` (default is `:memory:`)

---

## Scheduled jobs (simple worker)

ClearSignal includes a basic “jobs” loop for *scheduled* re-analysis (starter scaffolding).

1) Start the API:
```bash
make cloud
```

2) In another terminal, start the worker:
```bash
make worker
```

3) Create a job in the UI (Jobs tab), or via API:
- `POST /jobs` (upload CSV + schedule)
- `POST /jobs/{id}/run` (run immediately)
- `GET /jobs` (list)

This is intentionally minimal and explainable. In a production SaaS you’d typically swap the worker for
a proper queue (Celery/RQ/Temporal) and store datasets in object storage.

---

## Docker

```bash
docker compose up --build
```

---

## Disclaimer

ClearSignal can be used for health-related self-tracking, but it is not a medical device.
Use it to notice patterns and ask better questions — not to self-diagnose.
