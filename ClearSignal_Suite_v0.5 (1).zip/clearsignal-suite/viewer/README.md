# Viewer

Open `index.html` in a browser, click **Choose file**, and load a ClearSignal report JSON.

No dependencies. No build step. No server required.
