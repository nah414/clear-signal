const fileInput = document.getElementById('fileInput');
const summaryEl = document.getElementById('summary');
const alertsEl = document.getElementById('alerts');
const canvas = document.getElementById('chart');
const ctx = canvas.getContext('2d');
const signalSelect = document.getElementById('signalSelect');

let loadedReport = null;
let currentSignalReport = null;
let systemName = null;
let systemStatus = null;
let systemSummary = null;

fileInput.addEventListener('change', (e) => {
  const f = e.target.files[0];
  if (!f) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      loadedReport = JSON.parse(reader.result);
      setupReport(loadedReport);
    } catch (err) {
      summaryEl.innerHTML = `<h2>Error</h2><pre>${escapeHtml(String(err))}</pre>`;
    }
  };
  reader.readAsText(f);
});

signalSelect.addEventListener('change', () => {
  if (!loadedReport || !loadedReport.signals) return;
  const idx = parseInt(signalSelect.value, 10);
  currentSignalReport = loadedReport.signals[idx];
  renderAll(currentSignalReport, loadedReport.alerts || []);
});

function setupReport(report) {
  if (report && Array.isArray(report.signals)) {
    systemName = report.system_name || 'System';
    systemStatus = report.status || null;
    systemSummary = report.summary || null;

    signalSelect.style.display = '';
    signalSelect.innerHTML = '';
    report.signals.forEach((sr, i) => {
      const name = (sr.signal && sr.signal.name) ? sr.signal.name : `Signal ${i+1}`;
      const opt = document.createElement('option');
      opt.value = String(i);
      opt.textContent = `${name} — ${sr.status || 'unknown'}`;
      signalSelect.appendChild(opt);
    });
    signalSelect.value = '0';
    currentSignalReport = report.signals[0];
    renderAll(currentSignalReport, report.alerts || []);
  } else {
    systemName = null;
    systemStatus = null;
    systemSummary = null;

    signalSelect.style.display = 'none';
    currentSignalReport = report;
    renderAll(report, report.alerts || []);
  }
}

function renderAll(signalReport, systemAlerts) {
  renderSummary(signalReport, systemAlerts);
  renderAlerts(systemAlerts.length ? systemAlerts : (signalReport.alerts || []));
  renderChart(signalReport.series);
}

function renderSummary(r, systemAlerts) {
  const sig = r.signal || {};
  const drift = (r.summary && r.summary.drift) ? r.summary.drift : {};
  const recovery = (r.summary && r.summary.recovery) ? r.summary.recovery : {};
  const noise = (r.summary && r.summary.noise) ? r.summary.noise : {};
  const status = r.status || 'unknown';
  const badge = `<span class="badge ${status}">${status}</span>`;
  const alertCount = (systemAlerts && systemAlerts.length) ? systemAlerts.length : ((r.alerts||[]).length);

  let sysLine = '';
  if (systemName) {
    const sysBadge = systemStatus ? `<span class="badge ${systemStatus}">${systemStatus}</span>` : '';
    sysLine = `<div><small>System:</small> <strong>${escapeHtml(systemName)}</strong> ${sysBadge}</div>`;
  }

  let couplingLine = '';
  const coupling = (systemSummary && systemSummary.coupling) ? systemSummary.coupling : null;
  if (coupling && Number.isFinite(Number(coupling.delta))) {
    const base = Number.isFinite(Number(coupling.base_avg_abs_corr)) ? fmtNum(coupling.base_avg_abs_corr) : '—';
    const recent = Number.isFinite(Number(coupling.recent_avg_abs_corr)) ? fmtNum(coupling.recent_avg_abs_corr) : '—';
    couplingLine = `<div><small>Coupling Δ:</small> <code>${fmtNum(coupling.delta)}</code> <small>(avg |corr| ${base} → ${recent})</small></div>`;
  }

  summaryEl.innerHTML = `
    <h2>Summary</h2>
    ${sysLine}
    ${couplingLine}
    <div><strong>${escapeHtml(sig.name || 'signal')}</strong> ${badge} <small>${escapeHtml(sig.unit || '')}</small></div>
    <div class="meta">
      <div><small>Last date:</small> <code>${escapeHtml((r.summary && r.summary.last_date) || '')}</code></div>
      <div><small>Last value:</small> <code>${fmtNum(r.summary && r.summary.last_value)}</code></div>
      <div><small>Last expected:</small> <code>${fmtNum(r.summary && r.summary.last_expected)}</code></div>
      <div><small>Last z:</small> <code>${fmtNum(r.summary && r.summary.last_z)}</code></div>
      <div><small>Missing fraction:</small> <code>${fmtPct(r.summary && r.summary.missing_fraction)}</code></div>
      <div><small>Alerts:</small> <code>${alertCount}</code></div>
    </div>
    <hr/>
    <div class="meta">
      <div><small>Drift score:</small> <code>${fmtNum(drift.score)}</code> <small>(conf: ${fmtNum(drift.confidence)})</small></div>
      <div><small>Drift onset (hint):</small> <code>${escapeHtml(drift.change_point || '—')}</code></div>
      <div><small>Recovery score:</small> <code>${fmtNum(recovery.score)}</code> <small>(ratio: ${fmtNum(recovery.ratio)})</small></div>
      <div><small>Noise score:</small> <code>${fmtNum(noise.score)}</code> <small>(ratio: ${fmtNum(noise.ratio)})</small></div>
    </div>
  `;
}

function renderAlerts(alerts) {
  if (!alerts || !alerts.length) {
    alertsEl.innerHTML = `<p>No alerts. (Either stable, or not enough data.)</p>`;
    return;
  }
  alertsEl.innerHTML = alerts.map(a => {
    const status = a.status || 'watch';
    const badge = `<span class="badge ${status}">${status}</span>`;
    const sig = a.signal_name ? `<small>signal:</small> <code>${escapeHtml(a.signal_name)}</code>` : '';
    const score = `<small>score:</small> <code>${fmtNum(a.score)}</code>`;
    const conf = `<small>conf:</small> <code>${fmtNum(a.confidence)}</code>`;
    const when = a.created_at ? `<small>created:</small> <code>${escapeHtml(a.created_at)}</code>` : '';
    return `
      <div class="alert">
        <div><strong>${escapeHtml(a.title || a.type || 'alert')}</strong> ${badge}</div>
        <div style="margin-top:6px;">${escapeHtml(a.message || '')}</div>
        <div class="meta">${sig} ${score} ${conf} ${when}</div>
      </div>
    `;
  }).join('');
}

function renderChart(series) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (!series || !series.ts || !series.ts.length) {
    ctx.fillText("No series data in report.", 20, 30);
    return;
  }
  const ts = series.ts;
  const val = series.value || [];
  const lower = series.lower || [];
  const upper = series.upper || [];
  const expected = series.expected || [];

  const all = [];
  for (let i = 0; i < ts.length; i++) {
    [val[i], lower[i], upper[i], expected[i]].forEach(v => {
      if (v !== null && v !== undefined && Number.isFinite(v)) all.push(v);
    });
  }
  if (!all.length) {
    ctx.fillText("Series has no numeric points.", 20, 30);
    return;
  }
  const ymin = Math.min(...all);
  const ymax = Math.max(...all);
  const pad = (ymax - ymin) * 0.08 || 1;
  const y0 = ymin - pad;
  const y1 = ymax + pad;

  const W = canvas.width;
  const H = canvas.height;
  const margin = {l: 50, r: 20, t: 15, b: 35};
  const pw = W - margin.l - margin.r;
  const ph = H - margin.t - margin.b;

  const xToPx = (x) => margin.l + (x / Math.max(1, ts.length - 1)) * pw;
  const yToPx = (y) => margin.t + (1 - (y - y0) / (y1 - y0)) * ph;

  ctx.strokeStyle = "#e5e5e5";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(margin.l, margin.t);
  ctx.lineTo(margin.l, margin.t + ph);
  ctx.lineTo(margin.l + pw, margin.t + ph);
  ctx.stroke();

  ctx.fillStyle = "#444";
  ctx.font = "12px system-ui";
  const yTicks = [y0, (y0+y1)/2, y1];
  yTicks.forEach((y) => {
    const py = yToPx(y);
    ctx.fillText(y.toFixed(2), 6, py+4);
    ctx.strokeStyle = "#f0f0f0";
    ctx.beginPath();
    ctx.moveTo(margin.l, py);
    ctx.lineTo(margin.l + pw, py);
    ctx.stroke();
  });

  // shaded band
  ctx.fillStyle = "rgba(0,0,0,0.06)";
  ctx.beginPath();
  let started = false;
  for (let i = 0; i < ts.length; i++) {
    const lo = lower[i];
    if (lo === null || lo === undefined || !Number.isFinite(lo)) continue;
    const px = xToPx(i);
    const py = yToPx(lo);
    if (!started) { ctx.moveTo(px, py); started = true; }
    else ctx.lineTo(px, py);
  }
  for (let i = ts.length - 1; i >= 0; i--) {
    const up = upper[i];
    if (up === null || up === undefined || !Number.isFinite(up)) continue;
    const px = xToPx(i);
    const py = yToPx(up);
    ctx.lineTo(px, py);
  }
  if (started) ctx.closePath();
  ctx.fill();

  drawLine(expected, "#999", 1.5);
  drawLine(val, "#111", 2.0);

  const labels = [
    {i: 0, t: ts[0]},
    {i: Math.floor((ts.length-1)/2), t: ts[Math.floor((ts.length-1)/2)]},
    {i: ts.length-1, t: ts[ts.length-1]},
  ];
  labels.forEach(o => {
    ctx.fillText(o.t, xToPx(o.i) - 30, margin.t + ph + 20);
  });

  function drawLine(arr, strokeStyle, width) {
    ctx.strokeStyle = strokeStyle;
    ctx.lineWidth = width;
    ctx.beginPath();
    let started = false;
    for (let i = 0; i < arr.length; i++) {
      const y = arr[i];
      if (y === null || y === undefined || !Number.isFinite(y)) continue;
      const px = xToPx(i);
      const py = yToPx(y);
      if (!started) { ctx.moveTo(px, py); started = true; }
      else ctx.lineTo(px, py);
    }
    if (started) ctx.stroke();
  }
}

function escapeHtml(s) {
  return s.replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}
function fmtNum(x) {
  if (x === null || x === undefined || !Number.isFinite(Number(x))) return "—";
  return Number(x).toFixed(3);
}
function fmtPct(x) {
  if (x === null || x === undefined || !Number.isFinite(Number(x))) return "—";
  return (Number(x)*100).toFixed(1) + "%";
}
