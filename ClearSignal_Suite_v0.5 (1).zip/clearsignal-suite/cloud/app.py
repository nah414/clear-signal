from __future__ import annotations

import json
import os
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd
from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from clearsignal_core.calibrate import calibrate_signal
from clearsignal_core.ingest import parse_timeseries_df
from clearsignal_core.report import analyze_signal, analyze_system
from clearsignal_core.template_loader import list_available_templates

from cloud.db import (
    connect,
    create_job,
    get_report,
    list_jobs,
    list_reports,
    run_job,
    set_job_enabled,
    store_report,
)


def require_api_key(x_api_key: Optional[str] = Header(default=None)) -> None:
    expected = os.environ.get("CLEAR_API_KEY")
    if not expected:
        return
    if x_api_key != expected:
        raise HTTPException(status_code=401, detail="Missing or invalid API key (set header X-API-Key)")


app = FastAPI(title="ClearSignal Cloud", version="0.5.0")

# Serve the minimal UI
UI_DIR = Path(__file__).parent / "ui"
if UI_DIR.exists():
    app.mount("/ui", StaticFiles(directory=str(UI_DIR), html=True), name="ui")


@app.get("/")
def root():
    return RedirectResponse(url="/ui/")


@app.get("/health")
def health():
    return {"ok": True}


@app.get("/templates", dependencies=[Depends(require_api_key)])
def templates():
    return JSONResponse({"templates": list_available_templates(), "note": "Templates are explainable JSON configs."})


async def _read_csv(upload: UploadFile) -> pd.DataFrame:
    raw = await upload.read()
    if not raw:
        raise HTTPException(status_code=400, detail="Empty CSV upload")
    try:
        return pd.read_csv(BytesIO(raw))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not parse CSV: {e}")


def _parse_cols(s: str) -> List[str]:
    cols = [c for c in s.replace(",", " ").split() if c.strip()]
    return cols


@app.post("/analyze", dependencies=[Depends(require_api_key)])
async def analyze(
    csv: UploadFile = File(...),
    ts: str = Form(...),
    value: str = Form(...),
    template: str = Form("default"),
    agg: str = Form("median"),
    store: str = Form("false"),
):
    df = await _read_csv(csv)
    ts_df = parse_timeseries_df(df, ts, [value])
    series = ts_df[value]

    report = analyze_signal(series, signal_name=value, template=template, agg=agg).to_dict()

    do_store = str(store).lower() in {"1", "true", "yes", "y"}
    if do_store:
        conn = connect()
        rid = store_report(conn, kind="signal", system_name=value, report=report)
        conn.close()
        return {"report_id": rid, "report": report}
    return report


@app.post("/analyze-system", dependencies=[Depends(require_api_key)])
async def analyze_system_endpoint(
    csv: UploadFile = File(...),
    ts: str = Form(...),
    values: str = Form(...),
    system_name: str = Form(...),
    template: str = Form("default"),
    agg: str = Form("median"),
    store: str = Form("false"),
):
    cols = _parse_cols(values)
    if len(cols) < 2:
        raise HTTPException(status_code=400, detail="values must contain at least 2 columns")
    df = await _read_csv(csv)
    ts_df = parse_timeseries_df(df, ts, cols)

    report = analyze_system(ts_df, system_name=system_name, template=template, agg=agg).to_dict()

    do_store = str(store).lower() in {"1", "true", "yes", "y"}
    if do_store:
        conn = connect()
        rid = store_report(conn, kind="system", system_name=system_name, report=report)
        conn.close()
        return {"report_id": rid, "report": report}
    return report


@app.post("/calibrate", dependencies=[Depends(require_api_key)])
async def calibrate(
    csv: UploadFile = File(...),
    ts: str = Form(...),
    value: str = Form(...),
    template: str = Form("default"),
    agg: str = Form("median"),
    target_outside: float = Form(0.02),
    target_drift: float = Form(0.05),
):
    df = await _read_csv(csv)
    ts_df = parse_timeseries_df(df, ts, [value])
    series = ts_df[value]
    return calibrate_signal(
        series,
        template=template,
        agg=agg,
        target_outside=float(target_outside),
        target_drift=float(target_drift),
    )


@app.get("/reports", dependencies=[Depends(require_api_key)])
def reports(limit: int = 50):
    conn = connect()
    rows = list_reports(conn, limit=int(limit))
    conn.close()
    return {"reports": rows}


@app.get("/reports/{report_id}", dependencies=[Depends(require_api_key)])
def report(report_id: str):
    conn = connect()
    rep = get_report(conn, report_id)
    conn.close()
    if rep is None:
        raise HTTPException(status_code=404, detail="Report not found")
    return JSONResponse(rep)


@app.post("/jobs", dependencies=[Depends(require_api_key)])
async def jobs_create(
    csv: UploadFile = File(...),
    name: str = Form(...),
    kind: str = Form(...),  # signal|system
    ts: str = Form(...),
    template: str = Form("default"),
    agg: str = Form("median"),
    interval_minutes: int = Form(1440),
    webhook_url: Optional[str] = Form(None),
    system_name: Optional[str] = Form(None),
    value: Optional[str] = Form(None),
    values: Optional[str] = Form(None),
):
    raw = await csv.read()
    if not raw:
        raise HTTPException(status_code=400, detail="Empty CSV upload")
    kind = str(kind).strip()
    if kind not in {"signal", "system"}:
        raise HTTPException(status_code=400, detail="kind must be 'signal' or 'system'")

    if kind == "signal":
        if not value:
            raise HTTPException(status_code=400, detail="value is required for kind=signal")
        value_cols = [value.strip()]
        sys_name = value.strip()
    else:
        if not values:
            raise HTTPException(status_code=400, detail="values is required for kind=system")
        value_cols = _parse_cols(values)
        if len(value_cols) < 2:
            raise HTTPException(status_code=400, detail="system job requires at least 2 value columns")
        if not system_name:
            raise HTTPException(status_code=400, detail="system_name is required for kind=system")
        sys_name = system_name.strip()

    conn = connect()
    out = create_job(
        conn,
        name=str(name).strip() or "job",
        kind=kind,
        system_name=sys_name,
        ts_col=str(ts).strip(),
        value_cols=value_cols,
        template=str(template).strip() or "default",
        overrides=None,
        agg=str(agg).strip() or "median",
        exclude_annotated=False,
        interval_minutes=int(interval_minutes),
        webhook_url=webhook_url,
        csv_bytes=raw,
    )
    conn.close()
    return out


@app.get("/jobs", dependencies=[Depends(require_api_key)])
def jobs(limit: int = 50):
    conn = connect()
    rows = list_jobs(conn, limit=int(limit))
    conn.close()
    return {"jobs": rows}


@app.post("/jobs/{job_id}/run", dependencies=[Depends(require_api_key)])
def jobs_run(job_id: str):
    conn = connect()
    out = run_job(conn, job_id, run_even_if_disabled=True)
    conn.close()
    return out


@app.post("/jobs/{job_id}/enable", dependencies=[Depends(require_api_key)])
def jobs_enable(job_id: str):
    conn = connect()
    set_job_enabled(conn, job_id, True)
    conn.close()
    return {"ok": True, "job_id": job_id, "enabled": True}


@app.post("/jobs/{job_id}/disable", dependencies=[Depends(require_api_key)])
def jobs_disable(job_id: str):
    conn = connect()
    set_job_enabled(conn, job_id, False)
    conn.close()
    return {"ok": True, "job_id": job_id, "enabled": False}
