const reportIdInput = document.getElementById('reportId');
const loadBtn = document.getElementById('loadBtn');

const apiKeyInput = document.getElementById('apiKey');
const saveKeyBtn = document.getElementById('saveKey');
const keyStatus = document.getElementById('keyStatus');

const summaryEl = document.getElementById('summary');
const alertsEl = document.getElementById('alerts');
const canvas = document.getElementById('chart');
const ctx = canvas.getContext('2d');

let loadedReport = null;
let currentSignalReport = null;

function getApiKey() {
  return localStorage.getItem('CLEAR_API_KEY') || '';
}
function setApiKey(k) {
  localStorage.setItem('CLEAR_API_KEY', k || '');
}
function authHeaders() {
  const k = getApiKey();
  return k ? {'X-API-Key': k} : {};
}
function syncKeyUI() {
  apiKeyInput.value = getApiKey();
  keyStatus.textContent = getApiKey() ? 'saved' : '';
}
syncKeyUI();
saveKeyBtn.addEventListener('click', () => {
  setApiKey(apiKeyInput.value.trim());
  syncKeyUI();
});

function qp(name) {
  const url = new URL(window.location.href);
  return url.searchParams.get(name);
}

async function loadReport(id) {
  summaryEl.innerHTML = '<h2>Loading…</h2>';
  alertsEl.innerHTML = '';
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const res = await fetch(`/reports/${encodeURIComponent(id)}`, {headers: authHeaders()});
  if (!res.ok) throw new Error(`${res.status} ${await res.text()}`);
  const report = await res.json();
  setupReport(report);
}

loadBtn.addEventListener('click', async () => {
  const id = reportIdInput.value.trim();
  if (!id) return;
  try {
    await loadReport(id);
    const url = new URL(window.location.href);
    url.searchParams.set('id', id);
    window.history.replaceState({}, '', url.toString());
  } catch (e) {
    summaryEl.innerHTML = `<h2>Error</h2><pre>${escapeHtml(String(e))}</pre>`;
  }
});

(function init() {
  const id = qp('id');
  if (id) {
    reportIdInput.value = id;
    loadReport(id).catch(e => {
      summaryEl.innerHTML = `<h2>Error</h2><pre>${escapeHtml(String(e))}</pre>`;
    });
  } else {
    summaryEl.innerHTML = `<h2>Enter a report ID</h2><p>Paste a report ID above, or open from the dashboard.</p>`;
  }
})();

function setupReport(report) {
  loadedReport = report;
  if (report && Array.isArray(report.signals)) {
    currentSignalReport = report.signals[0];
    renderAll(currentSignalReport, report.alerts || []);
  } else {
    currentSignalReport = report;
    renderAll(report, report.alerts || []);
  }
}

function renderAll(signalReport, systemAlerts) {
  renderSummary(signalReport, systemAlerts);
  renderAlerts(systemAlerts.length ? systemAlerts : (signalReport.alerts || []));
  renderChart(signalReport.series);
}

function renderSummary(r, systemAlerts) {
  const sig = r.signal || {};
  const drift = (r.summary && r.summary.drift) ? r.summary.drift : {};
  const recovery = (r.summary && r.summary.recovery) ? r.summary.recovery : {};
  const noise = (r.summary && r.summary.noise) ? r.summary.noise : {};
  const status = r.status || 'unknown';
  const badge = `<span class="badge ${status}">${status}</span>`;
  const alertCount = (systemAlerts && systemAlerts.length) ? systemAlerts.length : ((r.alerts||[]).length);

  const cp = drift.change_point ? `<div><small>Drift change point:</small> <code>${escapeHtml(String(drift.change_point))}</code></div>` : '';

  summaryEl.innerHTML = `
    <h2>Summary</h2>
    <div><strong>${escapeHtml(sig.name || 'signal')}</strong> ${badge} <small>${escapeHtml(sig.unit || '')}</small></div>
    <div class="meta">
      <div><small>Last date:</small> <code>${escapeHtml((r.summary && r.summary.last_date) || '')}</code></div>
      <div><small>Last value:</small> <code>${fmtNum(r.summary && r.summary.last_value)}</code></div>
      <div><small>Last expected:</small> <code>${fmtNum(r.summary && r.summary.last_expected)}</code></div>
      <div><small>Last z:</small> <code>${fmtNum(r.summary && r.summary.last_z)}</code></div>
      <div><small>Missing fraction:</small> <code>${fmtPct(r.summary && r.summary.missing_fraction)}</code></div>
      <div><small>Alerts:</small> <code>${alertCount}</code></div>
      ${cp}
    </div>
    <hr/>
    <div class="meta">
      <div><small>Drift score:</small> <code>${fmtNum(drift.score)}</code> <small>(conf: ${fmtNum(drift.confidence)})</small></div>
      <div><small>Recovery score:</small> <code>${fmtNum(recovery.score)}</code> <small>(ratio: ${fmtNum(recovery.ratio)})</small></div>
      <div><small>Noise score:</small> <code>${fmtNum(noise.score)}</code> <small>(ratio: ${fmtNum(noise.ratio)})</small></div>
    </div>
  `;
}

function renderAlerts(alerts) {
  if (!alerts || !alerts.length) {
    alertsEl.innerHTML = `<p>No alerts. (Either stable, or not enough data.)</p>`;
    return;
  }
  alertsEl.innerHTML = alerts.map(a => {
    const status = a.status || 'watch';
    const badge = `<span class="badge ${status}">${status}</span>`;
    const sig = a.signal_name ? `<small>signal:</small> <code>${escapeHtml(a.signal_name)}</code>` : '';
    const score = `<small>score:</small> <code>${fmtNum(a.score)}</code>`;
    const conf = `<small>conf:</small> <code>${fmtNum(a.confidence)}</code>`;
    const when = a.created_at ? `<small>created:</small> <code>${escapeHtml(a.created_at)}</code>` : '';
    return `
      <div class="alert">
        <div><strong>${escapeHtml(a.title || a.type || 'alert')}</strong> ${badge}</div>
        <div style="margin-top:6px;">${escapeHtml(a.message || '')}</div>
        <div class="meta">${sig} ${score} ${conf} ${when}</div>
      </div>
    `;
  }).join('');
}

function renderChart(series) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (!series || !series.ts || !series.ts.length) {
    ctx.fillText("No series data in report.", 20, 30);
    return;
  }
  const ts = series.ts;
  const val = series.value || [];
  const lower = series.lower || [];
  const upper = series.upper || [];
  const expected = series.expected || [];

  const all = [];
  for (let i = 0; i < ts.length; i++) {
    [val[i], lower[i], upper[i], expected[i]].forEach(v => {
      if (v !== null && v !== undefined && Number.isFinite(v)) all.push(v);
    });
  }
  if (!all.length) {
    ctx.fillText("Series has no numeric points.", 20, 30);
    return;
  }
  const ymin = Math.min(...all);
  const ymax = Math.max(...all);
  const pad = (ymax - ymin) * 0.08 || 1;
  const y0 = ymin - pad;
  const y1 = ymax + pad;

  const W = canvas.width;
  const H = canvas.height;
  const margin = {l: 50, r: 20, t: 15, b: 35};
  const pw = W - margin.l - margin.r;
  const ph = H - margin.t - margin.b;

  const xToPx = (x) => margin.l + (x / Math.max(1, ts.length - 1)) * pw;
  const yToPx = (y) => margin.t + (1 - (y - y0) / (y1 - y0)) * ph;

  ctx.strokeStyle = "#e5e5e5";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(margin.l, margin.t);
  ctx.lineTo(margin.l, margin.t + ph);
  ctx.lineTo(margin.l + pw, margin.t + ph);
  ctx.stroke();

  ctx.fillStyle = "#444";
  ctx.font = "12px system-ui";
  const yTicks = [y0, (y0+y1)/2, y1];
  yTicks.forEach((y) => {
    const py = yToPx(y);
    ctx.fillText(y.toFixed(2), 6, py+4);
    ctx.strokeStyle = "#f0f0f0";
    ctx.beginPath();
    ctx.moveTo(margin.l, py);
    ctx.lineTo(margin.l + pw, py);
    ctx.stroke();
  });

  // shaded band
  ctx.fillStyle = "rgba(0,0,0,0.06)";
  ctx.beginPath();
  let started = false;
  for (let i = 0; i < ts.length; i++) {
    const lo = lower[i];
    if (lo === null || lo === undefined || !Number.isFinite(lo)) continue;
    const px = xToPx(i);
    const py = yToPx(lo);
    if (!started) { ctx.moveTo(px, py); started = true; }
    else ctx.lineTo(px, py);
  }
  for (let i = ts.length - 1; i >= 0; i--) {
    const up = upper[i];
    if (up === null || up === undefined || !Number.isFinite(up)) continue;
    const px = xToPx(i);
    const py = yToPx(up);
    ctx.lineTo(px, py);
  }
  if (started) ctx.closePath();
  ctx.fill();

  drawLine(expected, "#999", 1.5);
  drawLine(val, "#111", 2.0);

  const labels = [
    {i: 0, t: ts[0]},
    {i: Math.floor((ts.length-1)/2), t: ts[Math.floor((ts.length-1)/2)]},
    {i: ts.length-1, t: ts[ts.length-1]},
  ];
  labels.forEach(o => {
    ctx.fillText(o.t, xToPx(o.i) - 30, margin.t + ph + 20);
  });

  function drawLine(arr, strokeStyle, width) {
    ctx.strokeStyle = strokeStyle;
    ctx.lineWidth = width;
    ctx.beginPath();
    let started = false;
    for (let i = 0; i < arr.length; i++) {
      const y = arr[i];
      if (y === null || y === undefined || !Number.isFinite(y)) continue;
      const px = xToPx(i);
      const py = yToPx(y);
      if (!started) { ctx.moveTo(px, py); started = true; }
      else ctx.lineTo(px, py);
    }
    if (started) ctx.stroke();
  }
}

function escapeHtml(s) {
  return String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}
function fmtNum(x) {
  if (x === null || x === undefined || !Number.isFinite(Number(x))) return "—";
  return Number(x).toFixed(3);
}
function fmtPct(x) {
  if (x === null || x === undefined || !Number.isFinite(Number(x))) return "—";
  return (Number(x)*100).toFixed(1) + "%";
}
