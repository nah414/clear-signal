# ClearSignal Cloud

A minimal FastAPI API + tiny web UI for ClearSignal.

## Run locally

```bash
pip install -r requirements.txt
CLEAR_DB=clearsignal.db uvicorn cloud.app:app --reload --port 8000
```

Open:
- UI: http://localhost:8000/ui/
- API docs: http://localhost:8000/docs

## Security (optional)

Set an API key:

```bash
export CLEAR_API_KEY="your-secret"
```

Then send `X-API-Key: your-secret` with requests.
The UI supports saving the key in localStorage.

## Scheduled jobs

Jobs are stored in SQLite, and a simple worker executes them.

Terminal A (API):
```bash
export CLEAR_DB=clearsignal.db
uvicorn cloud.app:app --reload --port 8000
```

Terminal B (worker):
```bash
export CLEAR_DB=clearsignal.db
python cloud/worker.py
```

This is intentionally lightweight scaffolding. Swap for a proper queue in production.
