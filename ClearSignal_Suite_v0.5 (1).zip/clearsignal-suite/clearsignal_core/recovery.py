from __future__ import annotations

from datetime import timedelta
from typing import Any, Dict, List

import numpy as np
import pandas as pd

def compute_recovery(dev: pd.DataFrame, recovery_cfg: Dict[str, Any]) -> Dict[str, Any]:
    shock_z = float(recovery_cfg.get("shock_z", 2.5))
    recover_z = float(recovery_cfg.get("recover_z", 1.0))
    require_consecutive = int(recovery_cfg.get("require_consecutive_days", 1))

    baseline_days = int(recovery_cfg.get("baseline_days", 60))
    gap_days = int(recovery_cfg.get("gap_days", 7))
    recent_days = int(recovery_cfg.get("recent_days", 14))
    min_shocks = int(recovery_cfg.get("min_shocks", 2))
    eps = float(recovery_cfg.get("eps", 1e-9))

    if len(dev.index) == 0:
        return {"score": float("nan"), "confidence": 0.0, "reason": "no data"}

    idx = dev.index
    end = idx.max()
    recent_start = end - timedelta(days=recent_days - 1)
    baseline_end = recent_start - timedelta(days=gap_days + 1)
    baseline_start = baseline_end - timedelta(days=baseline_days - 1)

    absz = dev["absz"].to_numpy(dtype=float)

    base_mask = (idx >= baseline_start) & (idx <= baseline_end)
    recent_mask = (idx >= recent_start) & (idx <= end)

    events = _recovery_events(idx, absz, shock_z, recover_z, require_consecutive=require_consecutive)

    base_times = [e["recovery_days"] for e in events if base_mask[e["start_pos"]]]
    recent_times = [e["recovery_days"] for e in events if recent_mask[e["start_pos"]]]

    base_times = np.array(base_times, dtype=float)
    recent_times = np.array(recent_times, dtype=float)

    n_base = int(base_times.size)
    n_recent = int(recent_times.size)

    med_base = float(np.median(base_times)) if n_base else float("nan")
    med_recent = float(np.median(recent_times)) if n_recent else float("nan")

    if not np.isfinite(med_base) or not np.isfinite(med_recent):
        return {
            "score": float("nan"),
            "confidence": float(min(1.0, (n_base + n_recent) / max(1, min_shocks))),
            "reason": "insufficient shocks",
            "n_shocks_base": n_base,
            "n_shocks_recent": n_recent,
            "median_base_days": med_base,
            "median_recent_days": med_recent,
            "shock_z": shock_z,
            "recover_z": recover_z,
            "window": {
                "baseline_start": baseline_start.date().isoformat(),
                "baseline_end": baseline_end.date().isoformat(),
                "recent_start": recent_start.date().isoformat(),
                "recent_end": end.date().isoformat(),
            },
            "events_preview": events[-10:],
        }

    ratio = (med_recent + eps) / (med_base + eps)
    score = max(0.0, ratio - 1.0)

    confidence = float(min(1.0, min(n_base, n_recent) / max(1, min_shocks)))

    return {
        "score": float(score),
        "confidence": confidence,
        "n_shocks_base": n_base,
        "n_shocks_recent": n_recent,
        "median_base_days": med_base,
        "median_recent_days": med_recent,
        "ratio": ratio,
        "shock_z": shock_z,
        "recover_z": recover_z,
        "window": {
            "baseline_start": baseline_start.date().isoformat(),
            "baseline_end": baseline_end.date().isoformat(),
            "recent_start": recent_start.date().isoformat(),
            "recent_end": end.date().isoformat(),
        },
        "events_preview": events[-10:],
    }

def _recovery_events(idx: pd.DatetimeIndex, absz: np.ndarray, shock_z: float, recover_z: float, *, require_consecutive: int = 1) -> List[Dict[str, Any]]:
    n = len(idx)
    events: List[Dict[str, Any]] = []

    def is_shock(i: int) -> bool:
        return np.isfinite(absz[i]) and absz[i] >= shock_z

    def is_recovered(i: int) -> bool:
        return np.isfinite(absz[i]) and absz[i] < recover_z

    i = 0
    while i < n:
        if is_shock(i) and (i == 0 or not is_shock(i - 1)):
            start_i = i
            j = i + 1
            consec = 0
            recovered_at = None
            while j < n:
                if is_recovered(j):
                    consec += 1
                    if consec >= require_consecutive:
                        recovered_at = j
                        break
                else:
                    consec = 0
                j += 1
            if recovered_at is not None:
                days = int((idx[recovered_at].date() - idx[start_i].date()).days)
                events.append({
                    "start": idx[start_i].date().isoformat(),
                    "recovered": idx[recovered_at].date().isoformat(),
                    "recovery_days": days,
                    "start_pos": start_i,
                    "recovered_pos": recovered_at,
                })
            i = start_i + 1
        else:
            i += 1
    return events
