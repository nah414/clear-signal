from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from .annotations import annotations_overlapping
from .schemas import Alert, EvidenceBundle, Status, AnnotationInterval

def _now_iso() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

def _opt_floats(xs: List[Any]) -> List[Optional[float]]:
    out: List[Optional[float]] = []
    for x in xs:
        try:
            v = float(x)
            out.append(None if np.isnan(v) else v)
        except Exception:
            out.append(None)
    return out

def build_evidence(dev: pd.DataFrame, *, window_start: pd.Timestamp, window_end: pd.Timestamp, annotations: Sequence[AnnotationInterval] = ()) -> EvidenceBundle:
    idx_tz = getattr(dev.index, "tz", None)
    ws = pd.Timestamp(window_start)
    we = pd.Timestamp(window_end)
    if idx_tz is not None:
        if ws.tzinfo is None:
            ws = ws.tz_localize(idx_tz)
        else:
            ws = ws.tz_convert(idx_tz)
        if we.tzinfo is None:
            we = we.tz_localize(idx_tz)
        else:
            we = we.tz_convert(idx_tz)

    sub = dev.loc[(dev.index >= ws) & (dev.index <= we)].copy()
    ts = [d.date().isoformat() for d in sub.index]
    return EvidenceBundle(
        ts=ts,
        value=_opt_floats(sub["value"].to_list()),
        expected=_opt_floats(sub["expected"].to_list()),
        lower=_opt_floats(sub["lower"].to_list()),
        upper=_opt_floats(sub["upper"].to_list()),
        z=_opt_floats(sub["z"].to_list()),
        window_start=ws.date().isoformat(),
        window_end=we.date().isoformat(),
        annotations=annotations_overlapping(ws.date(), we.date(), annotations),
    )

def generate_alerts(signal_name: str, dev: pd.DataFrame, *, quality: Dict[str, Any], cfg: Dict[str, Any], drift: Dict[str, Any], recovery: Dict[str, Any], noise: Dict[str, Any], annotations: Sequence[AnnotationInterval] = ()) -> List[Alert]:
    alerts: List[Alert] = []
    now = _now_iso()

    missing_fraction = float(quality.get("missing_fraction", 0.0))
    if missing_fraction >= float(cfg.get("data_quality", {}).get("missing_fraction_warn", 0.25)):
        title = "Data quality: many missing days"
        msg = f"{missing_fraction:.0%} of days are missing. Results may be less reliable."
        end = dev.index.max()
        ev = build_evidence(dev, window_start=end - timedelta(days=60), window_end=end, annotations=annotations)
        alerts.append(Alert(type="data_quality", status="watch", score=missing_fraction, confidence=1.0, title=title, message=msg, signal_name=signal_name, created_at=now, evidence=ev))

    recent_days = int(cfg.get("drift", {}).get("recent_days", 14))
    end = dev.index.max()
    recent_start = end - timedelta(days=recent_days - 1)
    recent = dev.loc[(dev.index >= recent_start) & (dev.index <= end)]
    out_count = int(recent["out_of_band"].fillna(False).sum())
    min_breaks = int(cfg.get("baseline_break", {}).get("min_breaks", 2))
    if out_count >= min_breaks:
        score = out_count / max(1, recent_days)
        confidence = float(min(1.0, recent["value"].notna().mean()))
        title = "Baseline breaks"
        msg = f"{out_count} day(s) in the last {recent_days} were outside your normal band."
        ev = build_evidence(dev, window_start=recent_start - timedelta(days=14), window_end=end, annotations=annotations)
        alerts.append(Alert(type="baseline_break", status="watch", score=float(score), confidence=float(confidence), title=title, message=msg, signal_name=signal_name, created_at=now, evidence=ev))

    drift_threshold = float(cfg.get("drift", {}).get("threshold", 1.2))
    drift_watch = float(cfg.get("drift", {}).get("watch_threshold", max(0.8, drift_threshold * 0.75)))
    drift_score = float(drift.get("score", float("nan")))
    drift_conf = float(drift.get("confidence", 0.0))
    if np.isfinite(drift_score) and drift_conf >= float(cfg.get("drift", {}).get("min_confidence", 0.4)):
        status: Optional[Status]
        if drift_score >= drift_threshold:
            status = "drift"
        elif drift_score >= drift_watch:
            status = "watch"
        else:
            status = None
        if status:
            title = "Drift detected" if status == "drift" else "Possible drift"
            win = drift.get("window", {})
            ws = pd.to_datetime(win.get("baseline_start", recent_start.date().isoformat()))
            we = pd.to_datetime(win.get("recent_end", end.date().isoformat()))
            ev = build_evidence(dev, window_start=ws, window_end=we, annotations=annotations)
            cp = drift.get("change_point")
            msg = f"Recent behavior differs from your baseline. Median shift: {float(drift.get('median_shift', float('nan'))):.2f} z, variance ratio: {float(drift.get('var_ratio', float('nan'))):.2f}."
            if cp:
                msg += f" Approx change onset: {cp}."
            alerts.append(Alert(type="drift", status=status, score=float(drift_score), confidence=float(drift_conf), title=title, message=msg, signal_name=signal_name, created_at=now, evidence=ev))

    rec_threshold = float(cfg.get("recovery", {}).get("threshold", 0.5))
    rec_score = float(recovery.get("score", float("nan")))
    rec_conf = float(recovery.get("confidence", 0.0))
    if np.isfinite(rec_score) and rec_conf >= float(cfg.get("recovery", {}).get("min_confidence", 0.3)):
        if rec_score >= rec_threshold:
            ratio = float(recovery.get("ratio", float("nan")))
            med_base = float(recovery.get("median_base_days", float("nan")))
            med_recent = float(recovery.get("median_recent_days", float("nan")))
            title = "Recovery is slowing"
            msg = f"After shocks (abs(z) ≥ {recovery.get('shock_z', 2.5)}), median recovery time increased from ~{med_base:.1f} to ~{med_recent:.1f} day(s) (×{ratio:.2f})."
            ws = pd.to_datetime(recovery.get("window", {}).get("baseline_start", recent_start.date().isoformat()))
            we = pd.to_datetime(recovery.get("window", {}).get("recent_end", end.date().isoformat()))
            ev = build_evidence(dev, window_start=ws, window_end=we, annotations=annotations)
            alerts.append(Alert(type="recovery_slowing", status="watch", score=float(rec_score), confidence=float(rec_conf), title=title, message=msg, signal_name=signal_name, created_at=now, evidence=ev))

    noise_threshold = float(cfg.get("noise", {}).get("threshold", 0.4))
    noise_score = float(noise.get("score", float("nan")))
    noise_conf = float(noise.get("confidence", 0.0))
    if np.isfinite(noise_score) and noise_conf >= float(cfg.get("noise", {}).get("min_confidence", 0.3)):
        if noise_score >= noise_threshold:
            ratio = float(noise.get("ratio", float("nan")))
            title = "Noise is rising"
            msg = f"Residual variance increased (×{ratio:.2f}) between baseline and recent windows."
            ws = pd.to_datetime(noise.get("window", {}).get("baseline_start", recent_start.date().isoformat()))
            we = pd.to_datetime(noise.get("window", {}).get("recent_end", end.date().isoformat()))
            ev = build_evidence(dev, window_start=ws, window_end=we, annotations=annotations)
            alerts.append(Alert(type="noise_rising", status="watch", score=float(noise_score), confidence=float(noise_conf), title=title, message=msg, signal_name=signal_name, created_at=now, evidence=ev))

    def _rank(a: Alert) -> Tuple[int, float]:
        sev = {"stable": 0, "watch": 1, "drift": 2}[a.status]
        return (sev, float(a.score))

    alerts = sorted(alerts, key=_rank, reverse=True)
    max_alerts = int(cfg.get("alerts", {}).get("max_alerts", 8))
    return alerts[:max_alerts]
