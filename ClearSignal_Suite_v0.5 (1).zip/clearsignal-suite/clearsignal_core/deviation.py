from __future__ import annotations

import numpy as np
import pandas as pd

def compute_deviation(series: pd.Series, baseline: pd.DataFrame) -> pd.DataFrame:
    s = series.astype(float)
    expected = baseline["expected"].astype(float)
    lower = baseline["lower"].astype(float)
    upper = baseline["upper"].astype(float)
    scale = baseline["scale"].astype(float).replace(0.0, np.nan)

    residual = s - expected
    z = residual / scale
    absz = z.abs()
    out_of_band = (s < lower) | (s > upper)

    return pd.DataFrame({
        "value": s,
        "expected": expected,
        "lower": lower,
        "upper": upper,
        "scale": scale,
        "residual": residual,
        "z": z,
        "absz": absz,
        "out_of_band": out_of_band,
    })
