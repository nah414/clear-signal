from __future__ import annotations

import json
from datetime import date, datetime
from typing import Any, Dict, List, Optional, Sequence

import pandas as pd

from .schemas import AnnotationInterval

def load_annotations(path: str) -> List[AnnotationInterval]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        raise ValueError("annotations must be a JSON list")
    out: List[AnnotationInterval] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        start = _parse_date(item.get("start"))
        end = _parse_date(item.get("end") or item.get("start"))
        label = str(item.get("label") or "")
        if start is None or end is None:
            continue
        if end < start:
            start, end = end, start
        out.append(AnnotationInterval(start=start, end=end, label=label))
    return out

def _parse_date(x: Any) -> Optional[date]:
    if x is None:
        return None
    if isinstance(x, date) and not isinstance(x, datetime):
        return x
    if isinstance(x, datetime):
        return x.date()
    if isinstance(x, str):
        s = x.strip()
        if not s:
            return None
        return datetime.fromisoformat(s).date()
    return None

def mask_from_annotations(idx: pd.DatetimeIndex, intervals: Sequence[AnnotationInterval]) -> pd.Series:
    if not intervals:
        return pd.Series(True, index=idx)
    dates = pd.Index([d.date() for d in idx])
    keep = pd.Series(True, index=idx)
    for interval in intervals:
        in_interval = (dates >= interval.start) & (dates <= interval.end)
        keep.loc[in_interval.values] = False
    return keep

def annotations_overlapping(start: date, end: date, intervals: Sequence[AnnotationInterval]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for interval in intervals:
        if interval.end < start or interval.start > end:
            continue
        out.append({"start": interval.start.isoformat(), "end": interval.end.isoformat(), "label": interval.label})
    return out
