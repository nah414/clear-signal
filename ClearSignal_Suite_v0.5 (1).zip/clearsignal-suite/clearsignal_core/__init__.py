"""ClearSignal core engine (local-first, explainable time-series monitoring)."""

from .report import analyze_signal, analyze_system  # noqa: F401
