from __future__ import annotations

from datetime import timedelta
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .baseline import compute_baseline
from .deviation import compute_deviation
from .drift import compute_drift
from .noise import compute_noise
from .preprocess import to_daily_series
from .template_loader import load_template, apply_overrides


def calibrate_signal(
    series: pd.Series,
    *,
    template: str = "default",
    overrides: Optional[Dict[str, str]] = None,
    agg: str = "median",
    target_outside_fraction: float = 0.02,
    target_drift_fraction: float = 0.05,
    target_noise_fraction: float = 0.05,
    calibration_days: int = 180,
) -> Dict[str, Any]:
    """Calibrate thresholds from the user's own history (no population averages).

    Returns:
      {
        "recommended_overrides": {"baseline.k": 3.2, "drift.threshold": 1.25, ...},
        "details": {...}
      }
    """
    cfg = load_template(template)
    if overrides:
        cfg = apply_overrides(cfg, overrides)

    daily, quality = to_daily_series(series, agg=agg)
    baseline = compute_baseline(daily, cfg.get("baseline", {}))
    dev = compute_deviation(daily, baseline)

    rec: Dict[str, Any] = {}
    details: Dict[str, Any] = {"quality": quality}

    # ---- baseline.k calibration (use baseline window prior to recent window) ----
    drift_cfg = cfg.get("drift", {})
    win = _window_bounds(dev.index, drift_cfg, calibration_days=None)
    if win is not None:
        base_start, base_end, recent_start, end = win
        absz_base = dev.loc[(dev.index >= base_start) & (dev.index <= base_end), "absz"].dropna().to_numpy(dtype=float)
        k = _quantile_k(absz_base, target_outside_fraction)
        if k is not None:
            rec["baseline.k"] = float(k)
            details["baseline_k"] = {
                "computed_on": {"baseline_start": base_start.date().isoformat(), "baseline_end": base_end.date().isoformat()},
                "target_outside_fraction": float(target_outside_fraction),
                "n_points": int(absz_base.size),
                "k": float(k),
            }

    # ---- drift.threshold calibration via backtesting drift scores ----
    drift_scores = _backtest_scores(dev, metric="drift", cfg=cfg, days=calibration_days)
    if drift_scores.size > 0:
        thr = _quantile_threshold(drift_scores, target_drift_fraction)
        if thr is not None and np.isfinite(thr):
            rec["drift.threshold"] = float(thr)
            details["drift_threshold"] = {
                "target_fraction": float(target_drift_fraction),
                "n_windows": int(drift_scores.size),
                "threshold": float(thr),
                "score_quantiles": _quantiles(drift_scores),
            }

    # ---- noise.threshold calibration via backtesting noise scores ----
    noise_scores = _backtest_scores(dev, metric="noise", cfg=cfg, days=calibration_days)
    if noise_scores.size > 0:
        thr = _quantile_threshold(noise_scores, target_noise_fraction)
        if thr is not None and np.isfinite(thr):
            rec["noise.threshold"] = float(thr)
            details["noise_threshold"] = {
                "target_fraction": float(target_noise_fraction),
                "n_windows": int(noise_scores.size),
                "threshold": float(thr),
                "score_quantiles": _quantiles(noise_scores),
            }

    return {
        "recommended_overrides": rec,
        "details": details,
    }


def _quantile_k(absz: np.ndarray, target_outside_fraction: float, *, min_k: float = 1.5, max_k: float = 6.0) -> Optional[float]:
    if absz is None:
        return None
    absz = absz[np.isfinite(absz)]
    if absz.size < 20:
        return None
    target = float(target_outside_fraction)
    target = min(max(target, 0.0005), 0.2)
    q = float(np.quantile(absz, 1.0 - target))
    return float(min(max(q, min_k), max_k))


def _quantile_threshold(scores: np.ndarray, target_fraction: float) -> Optional[float]:
    scores = scores[np.isfinite(scores)]
    if scores.size < 30:
        return None
    p = float(target_fraction)
    p = min(max(p, 0.001), 0.5)
    return float(np.quantile(scores, 1.0 - p))


def _window_bounds(idx: pd.DatetimeIndex, drift_cfg: Dict[str, Any], calibration_days: Optional[int]) -> Optional[Tuple[pd.Timestamp, pd.Timestamp, pd.Timestamp, pd.Timestamp]]:
    if len(idx) == 0:
        return None
    end = idx.max()
    if calibration_days is not None:
        end = max(end - timedelta(days=0), end)
    baseline_days = int(drift_cfg.get("baseline_days", 60))
    gap_days = int(drift_cfg.get("gap_days", 7))
    recent_days = int(drift_cfg.get("recent_days", 14))
    recent_start = end - timedelta(days=recent_days - 1)
    baseline_end = recent_start - timedelta(days=gap_days + 1)
    baseline_start = baseline_end - timedelta(days=baseline_days - 1)
    return (baseline_start, baseline_end, recent_start, end)


def _backtest_scores(dev: pd.DataFrame, *, metric: str, cfg: Dict[str, Any], days: int = 180, step: int = 1) -> np.ndarray:
    if len(dev.index) == 0:
        return np.array([])
    idx = dev.index
    end = idx.max()
    start = max(idx.min(), end - timedelta(days=days))
    ends = [t for t in idx if t >= start][::step]
    scores: List[float] = []
    for t in ends:
        sub = dev.loc[dev.index <= t]
        if metric == "drift":
            out = compute_drift(sub, cfg.get("drift", {}))
        elif metric == "noise":
            out = compute_noise(sub, cfg.get("noise", {}))
        else:
            continue
        sc = out.get("score", float("nan"))
        conf = out.get("confidence", 0.0)
        if np.isfinite(sc) and float(conf) >= 0.4:
            scores.append(float(sc))
    return np.array(scores, dtype=float)


def _quantiles(arr: np.ndarray) -> Dict[str, float]:
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return {}
    qs = [0.1, 0.25, 0.5, 0.75, 0.9, 0.95]
    return {f"q{int(q*100)}": float(np.quantile(arr, q)) for q in qs}
