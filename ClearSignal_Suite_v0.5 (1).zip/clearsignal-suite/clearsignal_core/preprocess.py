from __future__ import annotations

from typing import Any, Dict, Literal, Tuple

import pandas as pd

Agg = Literal["mean", "sum", "median", "last"]

def to_daily_series(series: pd.Series, *, agg: Agg = "median") -> Tuple[pd.Series, Dict[str, Any]]:
    s = series.copy()
    if not isinstance(s.index, pd.DatetimeIndex):
        raise TypeError("series must have a DatetimeIndex")
    s = s.sort_index()

    if agg == "mean":
        daily = s.resample("D").mean()
    elif agg == "sum":
        daily = s.resample("D").sum(min_count=1)
    elif agg == "last":
        daily = s.resample("D").last()
    else:
        daily = s.resample("D").median()

    if len(daily.index) == 0:
        return daily, {"agg": agg, "total_days": 0, "non_missing_days": 0, "missing_days": 0, "missing_fraction": 1.0, "start": None, "end": None}

    total_days = int((daily.index.max() - daily.index.min()).days) + 1
    missing_days = int(daily.isna().sum())
    non_missing_days = int(daily.notna().sum())
    missing_fraction = float(missing_days / total_days) if total_days > 0 else 1.0

    quality = {
        "agg": agg,
        "total_days": total_days,
        "non_missing_days": non_missing_days,
        "missing_days": missing_days,
        "missing_fraction": missing_fraction,
        "start": daily.index.min().date().isoformat(),
        "end": daily.index.max().date().isoformat(),
    }
    return daily, quality

def to_daily_frame(df: pd.DataFrame, *, agg: Agg = "median") -> Tuple[pd.DataFrame, Dict[str, Any]]:
    if not isinstance(df.index, pd.DatetimeIndex):
        raise TypeError("df must have a DatetimeIndex")
    cols_quality = {}
    out = {}
    for c in df.columns:
        s, q = to_daily_series(df[c], agg=agg)
        out[c] = s
        cols_quality[c] = q
    daily = pd.DataFrame(out)
    total_days = int((daily.index.max() - daily.index.min()).days) + 1 if len(daily.index) else 0
    return daily, {"columns": cols_quality, "total_days": total_days}
