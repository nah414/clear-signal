from __future__ import annotations

from datetime import timedelta
from typing import Any, Dict, Optional, Tuple

import numpy as np
import pandas as pd


def compute_coupling(z_df: pd.DataFrame, coupling_cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Detect increased coupling between multiple signals.

    Idea:
      - Compute correlation matrices on z-scores in a baseline window and a recent window.
      - Summarize coupling as mean absolute off-diagonal correlation.
      - Score is the *increase* in coupling (recent - baseline), clipped at 0.

    This is intentionally simple and explainable: "signals are moving together more than they used to."
    """
    baseline_days = int(coupling_cfg.get("baseline_days", 60))
    gap_days = int(coupling_cfg.get("gap_days", 7))
    recent_days = int(coupling_cfg.get("recent_days", 14))
    min_periods = int(coupling_cfg.get("min_periods", max(7, recent_days // 2)))
    min_points = int(coupling_cfg.get("min_points", max(10, recent_days)))
    rolling_days = int(coupling_cfg.get("rolling_days", 14))

    if z_df is None or z_df.shape[1] < 2 or len(z_df.index) == 0:
        return {"score": float("nan"), "confidence": 0.0, "reason": "need >= 2 signals"}

    idx = z_df.index
    end = idx.max()
    recent_start = end - timedelta(days=recent_days - 1)
    baseline_end = recent_start - timedelta(days=gap_days + 1)
    baseline_start = baseline_end - timedelta(days=baseline_days - 1)

    base = z_df.loc[(idx >= baseline_start) & (idx <= baseline_end)]
    recent = z_df.loc[(idx >= recent_start) & (idx <= end)]

    if base.shape[0] < 3 or recent.shape[0] < 3:
        return {"score": float("nan"), "confidence": 0.0, "reason": "insufficient data"}

    C_base = base.corr(min_periods=min_periods)
    C_recent = recent.corr(min_periods=min_periods)

    base_avg = _avg_abs_offdiag(C_base)
    recent_avg = _avg_abs_offdiag(C_recent)

    if not np.isfinite(base_avg) or not np.isfinite(recent_avg):
        return {"score": float("nan"), "confidence": 0.0, "reason": "cannot compute correlations"}

    delta = float(recent_avg - base_avg)
    score = max(0.0, delta)

    # Matrix distance as extra evidence
    diff = C_recent.fillna(0.0) - C_base.fillna(0.0)
    frob = float(np.linalg.norm(diff.to_numpy()))

    # Confidence: window lengths + average missingness
    cov_base = float(base.notna().mean().mean())
    cov_recent = float(recent.notna().mean().mean())
    cov = min(cov_base, cov_recent)
    conf_len = min(1.0, min(base.shape[0], recent.shape[0]) / max(1, min_points))
    conf_sig = min(1.0, (z_df.shape[1] - 1) / 4.0)  # saturate after ~5 signals
    confidence = float(max(0.0, min(1.0, cov * conf_len * conf_sig)))

    # Optional rolling coupling series for evidence / future plotting
    roll_series = None
    try:
        roll_series = _rolling_coupling(z_df, rolling_days=rolling_days, min_periods=min_periods)
    except Exception:
        roll_series = None

    payload: Dict[str, Any] = {
        "score": float(score),
        "confidence": confidence,
        "base_avg_abs_corr": float(base_avg),
        "recent_avg_abs_corr": float(recent_avg),
        "delta": float(delta),
        "frob_norm": float(frob),
        "n_signals": int(z_df.shape[1]),
        "window": {
            "baseline_start": baseline_start.date().isoformat(),
            "baseline_end": baseline_end.date().isoformat(),
            "recent_start": recent_start.date().isoformat(),
            "recent_end": end.date().isoformat(),
        },
    }
    if roll_series is not None:
        payload["rolling"] = {
            "days": rolling_days,
            "ts": [d.date().isoformat() for d in roll_series.index],
            "value": [None if not np.isfinite(v) else float(v) for v in roll_series.to_numpy(dtype=float)],
        }
    return payload


def _avg_abs_offdiag(C: pd.DataFrame) -> float:
    if C is None or C.shape[0] < 2:
        return float("nan")
    A = C.to_numpy(dtype=float)
    n = A.shape[0]
    iu = np.triu_indices(n, 1)
    off = A[iu]
    off = off[np.isfinite(off)]
    if off.size == 0:
        return float("nan")
    return float(np.mean(np.abs(off)))


def _rolling_coupling(z_df: pd.DataFrame, *, rolling_days: int, min_periods: int) -> pd.Series:
    """For each day t, compute avg abs off-diagonal correlation over trailing rolling_days."""
    idx = z_df.index
    out = []
    out_idx = []
    for i in range(len(idx)):
        start = idx[i] - timedelta(days=rolling_days - 1)
        win = z_df.loc[(idx >= start) & (idx <= idx[i])]
        if win.shape[0] < max(3, min_periods):
            out.append(np.nan)
            out_idx.append(idx[i])
            continue
        C = win.corr(min_periods=min_periods)
        out.append(_avg_abs_offdiag(C))
        out_idx.append(idx[i])
    return pd.Series(out, index=pd.DatetimeIndex(out_idx))
