from __future__ import annotations

from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from .alerts import generate_alerts
from .annotations import load_annotations
from .baseline import compute_baseline
from .deviation import compute_deviation
from .drift import compute_drift
from .coupling import compute_coupling
from .noise import compute_noise
from .preprocess import to_daily_series, to_daily_frame
from .recovery import compute_recovery
from .schemas import SignalReport, SystemReport, SignalSpec, Alert, EvidenceBundle
from .template_loader import load_template, apply_overrides

def analyze_signal(
    series: pd.Series,
    *,
    signal_name: str,
    unit: str = "",
    directionality: str = "neutral",
    template: str = "default",
    overrides: Optional[Dict[str, str]] = None,
    annotations_path: Optional[str] = None,
    exclude_annotated_from_baseline: bool = False,
    agg: str = "median",
) -> SignalReport:
    cfg = load_template(template)
    if overrides:
        cfg = apply_overrides(cfg, overrides)

    annotations = load_annotations(annotations_path) if annotations_path else []
    daily, quality = to_daily_series(series, agg=agg)

    baseline = compute_baseline(daily, cfg.get("baseline", {}), annotations=annotations, exclude_annotated=exclude_annotated_from_baseline)
    dev = compute_deviation(daily, baseline)

    drift = compute_drift(dev, cfg.get("drift", {}))
    recovery = compute_recovery(dev, cfg.get("recovery", {}))
    noise = compute_noise(dev, cfg.get("noise", {}))

    alerts = generate_alerts(signal_name, dev, quality=quality, cfg=cfg, drift=drift, recovery=recovery, noise=noise, annotations=annotations)
    status = _status_from_alerts(alerts)

    last = dev.iloc[-1] if len(dev) else None
    summary = {
        "last_date": dev.index.max().date().isoformat() if len(dev) else None,
        "last_value": _pyfloat(last["value"]) if last is not None else None,
        "last_expected": _pyfloat(last["expected"]) if last is not None else None,
        "last_z": _pyfloat(last["z"]) if last is not None else None,
        "missing_fraction": float(quality.get("missing_fraction", 1.0)),
        "drift": _select(drift, ["score", "confidence", "median_shift", "var_ratio", "ks", "absz_trend", "change_point", "change_score"]),
        "recovery": _select(recovery, ["score", "confidence", "median_base_days", "median_recent_days", "ratio", "shock_z", "recover_z"]),
        "noise": _select(noise, ["score", "confidence", "ratio"]),
    }

    series_out = _series_payload(dev, cfg.get("output", {}), quality)

    spec = SignalSpec(name=signal_name, unit=unit, directionality=directionality, cadence="daily")
    return SignalReport(signal=spec, status=status, summary=summary, alerts=alerts, series=series_out, config_used=cfg)

def analyze_system(
    df: pd.DataFrame,
    *,
    system_name: str,
    template: str = "default",
    overrides: Optional[Dict[str, str]] = None,
    annotations_path: Optional[str] = None,
    exclude_annotated_from_baseline: bool = False,
    agg: str = "median",
) -> SystemReport:
    cfg = load_template(template)
    if overrides:
        cfg = apply_overrides(cfg, overrides)

    annotations = load_annotations(annotations_path) if annotations_path else []
    daily_df, frame_quality = to_daily_frame(df, agg=agg)

    signal_reports: List[SignalReport] = []
    all_alerts: List[Alert] = []
    z_cols: Dict[str, pd.Series] = {}

    for col in daily_df.columns:
        daily = daily_df[col]
        quality = (frame_quality.get("columns", {}) or {}).get(col, {})

        baseline = compute_baseline(daily, cfg.get("baseline", {}), annotations=annotations, exclude_annotated=exclude_annotated_from_baseline)
        dev = compute_deviation(daily, baseline)

        drift = compute_drift(dev, cfg.get("drift", {}))
        recovery = compute_recovery(dev, cfg.get("recovery", {}))
        noise = compute_noise(dev, cfg.get("noise", {}))

        alerts = generate_alerts(col, dev, quality=quality, cfg=cfg, drift=drift, recovery=recovery, noise=noise, annotations=annotations)
        status = _status_from_alerts(alerts)

        last = dev.iloc[-1] if len(dev) else None
        summary = {
            "last_date": dev.index.max().date().isoformat() if len(dev) else None,
            "last_value": _pyfloat(last["value"]) if last is not None else None,
            "last_expected": _pyfloat(last["expected"]) if last is not None else None,
            "last_z": _pyfloat(last["z"]) if last is not None else None,
            "missing_fraction": float(quality.get("missing_fraction", 1.0)),
            "drift": _select(drift, ["score", "confidence", "median_shift", "var_ratio", "ks", "absz_trend", "change_point", "change_score"]),
            "recovery": _select(recovery, ["score", "confidence", "median_base_days", "median_recent_days", "ratio", "shock_z", "recover_z"]),
            "noise": _select(noise, ["score", "confidence", "ratio"]),
        }

        series_out = _series_payload(dev, cfg.get("output", {}), quality)
        spec = SignalSpec(name=col, unit="", directionality="neutral", cadence="daily")
        sr = SignalReport(signal=spec, status=status, summary=summary, alerts=alerts, series=series_out, config_used=cfg)
        signal_reports.append(sr)
        all_alerts.extend(alerts)

        z_cols[col] = dev["z"]

    # System-level coupling
    z_df = pd.DataFrame(z_cols) if z_cols else pd.DataFrame(index=daily_df.index)
    coupling_cfg = cfg.get("coupling", {})
    coupling = compute_coupling(z_df, coupling_cfg) if len(z_df.columns) >= 2 else {"score": float("nan"), "confidence": 0.0, "reason": "need >=2 signals"}

    # Optional coupling alert
    import numpy as np
    from datetime import datetime
    now = datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    try:
        score = float(coupling.get("score", float("nan")))
        conf = float(coupling.get("confidence", 0.0))
    except Exception:
        score, conf = float("nan"), 0.0

    threshold = float(coupling_cfg.get("threshold", 0.12))
    watch_threshold = float(coupling_cfg.get("watch_threshold", max(0.07, threshold * 0.6)))
    min_conf = float(coupling_cfg.get("min_confidence", 0.4))

    if np.isfinite(score) and conf >= min_conf and score >= watch_threshold:
        title = "Signals are coupling more than usual"
        base_avg = coupling.get("base_avg_abs_corr")
        recent_avg = coupling.get("recent_avg_abs_corr")
        msg = f"Cross-signal coupling increased (avg |corr| {float(base_avg):.2f} → {float(recent_avg):.2f}). This can indicate system-wide stress rather than an isolated blip."
        status = "watch" if score < threshold else "drift"

        rolling = (coupling.get("rolling") or {})
        ts = rolling.get("ts") or []
        val = rolling.get("value") or []
        if ts and val:
            expected = [None] * len(ts)
        else:
            ts, val, expected = [], [], []

        ev = EvidenceBundle(
            ts=ts,
            value=val,
            expected=expected,
            lower=[None] * len(ts),
            upper=[None] * len(ts),
            z=[None] * len(ts),
            window_start=(coupling.get("window") or {}).get("baseline_start"),
            window_end=(coupling.get("window") or {}).get("recent_end"),
            annotations=[],
        )
        all_alerts.append(Alert(
            type="coupling_increase",
            status=status,
            score=float(score),
            confidence=float(conf),
            title=title,
            message=msg,
            signal_name=system_name,
            created_at=now,
            evidence=ev,
        ))

    system_status = _status_from_alerts(all_alerts)
    all_alerts = sorted(all_alerts, key=lambda a: ({"stable": 0, "watch": 1, "drift": 2}[a.status], float(a.score)), reverse=True)
    max_alerts = int(cfg.get("alerts", {}).get("max_alerts", 12))
    all_alerts = all_alerts[:max_alerts]

    system_summary = {
        "n_signals": int(len(daily_df.columns)),
        "coupling": coupling,
    }

    return SystemReport(system_name=system_name, status=system_status, summary=system_summary, signal_reports=signal_reports, alerts=all_alerts, config_used=cfg)

def _status_from_alerts(alerts) -> str:
    if any(getattr(a, "status", None) == "drift" for a in alerts):
        return "drift"
    if len(alerts) > 0:
        return "watch"
    return "stable"

def _series_payload(dev: pd.DataFrame, out_cfg: Dict[str, Any], quality: Dict[str, Any]) -> Dict[str, Any]:
    max_points = int(out_cfg.get("max_points", 400))
    if len(dev) > max_points:
        dev = dev.iloc[-max_points:]
    ts = [d.date().isoformat() for d in dev.index]
    return {
        "ts": ts,
        "value": _opt_list(dev["value"].to_numpy(dtype=float)),
        "expected": _opt_list(dev["expected"].to_numpy(dtype=float)),
        "lower": _opt_list(dev["lower"].to_numpy(dtype=float)),
        "upper": _opt_list(dev["upper"].to_numpy(dtype=float)),
        "z": _opt_list(dev["z"].to_numpy(dtype=float)),
        "quality": quality,
    }

def _opt_list(arr: np.ndarray) -> List[Optional[float]]:
    out: List[Optional[float]] = []
    for v in arr:
        out.append(None if np.isnan(v) else float(v))
    return out

def _pyfloat(x: Any) -> Any:
    try:
        if x is None:
            return None
        v = float(x)
        return None if np.isnan(v) else v
    except Exception:
        return x

def _select(d: Dict[str, Any], keys: List[str]) -> Dict[str, Any]:
    out = {}
    for k in keys:
        if k in d:
            out[k] = _pyfloat(d[k])
    return out
