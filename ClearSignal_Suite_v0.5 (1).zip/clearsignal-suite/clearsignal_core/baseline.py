from __future__ import annotations

from typing import Any, Dict, Sequence

import numpy as np
import pandas as pd

from .annotations import mask_from_annotations
from .schemas import AnnotationInterval
from .utils import MAD_SCALE, mad, nanmedian, robust_scale, rolling_mad, rolling_median

def compute_baseline(
    series: pd.Series,
    baseline_cfg: Dict[str, Any],
    *,
    annotations: Sequence[AnnotationInterval] = (),
    exclude_annotated: bool = False,
) -> pd.DataFrame:
    method = str(baseline_cfg.get("method", "static"))
    seasonality = str(baseline_cfg.get("seasonality", "weekly"))
    k = float(baseline_cfg.get("k", 3.0))
    eps = float(baseline_cfg.get("eps", 1e-9))

    s = series.astype(float).copy()
    if exclude_annotated and annotations:
        keep = mask_from_annotations(s.index, annotations)
        s_fit = s[keep.values]
    else:
        s_fit = s

    if method == "rolling":
        window_days = int(baseline_cfg.get("rolling_window_days", 56))
        min_periods = int(baseline_cfg.get("rolling_min_periods", max(7, window_days // 4)))
        expected = rolling_median(s, window_days, min_periods=min_periods)
        m = rolling_mad(s, window_days, min_periods=min_periods)
        scale = (MAD_SCALE * m).fillna((MAD_SCALE * m).median())
        scale = scale.clip(lower=eps)
        lower = expected - k * scale
        upper = expected + k * scale
        return pd.DataFrame({"expected": expected, "lower": lower, "upper": upper, "scale": scale})

    if seasonality == "weekly":
        min_points = int(baseline_cfg.get("min_points_per_bucket", 10))
        g_median = nanmedian(s_fit.to_numpy())
        g_scale = robust_scale(s_fit.to_numpy(), eps=eps)

        medians = {}
        scales = {}
        for wd in range(7):
            vals = s_fit[s_fit.index.weekday == wd].to_numpy(dtype=float)
            vals = vals[~np.isnan(vals)]
            if vals.size >= min_points:
                med = float(np.median(vals))
                sc = float(MAD_SCALE * mad(vals))
                if not np.isfinite(sc) or sc < eps:
                    sc = g_scale
            else:
                med = g_median
                sc = g_scale
            medians[wd] = med
            scales[wd] = max(eps, sc)

        expected = pd.Series([medians[d] for d in s.index.weekday], index=s.index, dtype=float)
        scale = pd.Series([scales[d] for d in s.index.weekday], index=s.index, dtype=float)
        lower = expected - k * scale
        upper = expected + k * scale
        return pd.DataFrame({"expected": expected, "lower": lower, "upper": upper, "scale": scale})

    g_median = nanmedian(s_fit.to_numpy())
    g_scale = robust_scale(s_fit.to_numpy(), eps=eps)
    expected = pd.Series(g_median, index=s.index, dtype=float)
    scale = pd.Series(max(eps, g_scale), index=s.index, dtype=float)
    lower = expected - k * scale
    upper = expected + k * scale
    return pd.DataFrame({"expected": expected, "lower": lower, "upper": upper, "scale": scale})
